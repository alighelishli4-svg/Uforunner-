-- Version 5 economic/NFT update. Run once after 003_fan_ton_stars.sql.
ALTER TABLE users ADD COLUMN fun_balance INTEGER DEFAULT 0;
UPDATE users SET fun_balance=COALESCE(fan_balance,0);

INSERT OR IGNORE INTO settings(key,value) VALUES
 ('fun_enabled','0'),('fun_decimals','9'),('fun_token_address',''),('fun_buy_url',''),('fun_note','');
UPDATE settings SET value=COALESCE((SELECT value FROM settings WHERE key='fan_enabled'),'0') WHERE key='fun_enabled';
UPDATE settings SET value=COALESCE((SELECT value FROM settings WHERE key='fan_token_address'),'') WHERE key='fun_token_address';
UPDATE settings SET value=COALESCE((SELECT value FROM settings WHERE key='fan_decimals'),'9') WHERE key='fun_decimals';
UPDATE settings SET value=COALESCE((SELECT value FROM settings WHERE key='fan_buy_url'),'') WHERE key='fun_buy_url';
UPDATE settings SET value=COALESCE((SELECT value FROM settings WHERE key='fan_note'),'') WHERE key='fun_note';
DELETE FROM settings WHERE key IN ('fan_enabled','fan_token_address','fan_decimals','fan_buy_url','fan_note','page_airdrop');

CREATE TABLE IF NOT EXISTS ufo_inventory (
 ufo_id TEXT PRIMARY KEY, supply_total INTEGER NOT NULL, remaining INTEGER NOT NULL, sold_count INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO ufo_inventory(ufo_id,supply_total,remaining,sold_count) VALUES
 ('comet',5000,5000,0),('nova',2500,2500,0),('phantom',1250,1250,0),('vortex',625,625,0),('eclipse',300,300,0),('aurora',100,100,0);

-- Preserve every UFO ownership from the previous version as a legacy purchase record.
CREATE TABLE IF NOT EXISTS ufo_purchases (
 id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL, ufo_id TEXT NOT NULL, serial_no INTEGER NOT NULL,
 price_fun INTEGER NOT NULL DEFAULT 0, source TEXT NOT NULL DEFAULT 'legacy', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(ufo_id,serial_no)
);
INSERT OR IGNORE INTO ufo_purchases(telegram_id,ufo_id,serial_no,price_fun,source)
SELECT telegram_id,ufo_id,ROW_NUMBER() OVER(PARTITION BY ufo_id ORDER BY telegram_id),0,'legacy'
FROM user_ufos;

-- Reconcile the fixed supply against already-owned ships.
UPDATE ufo_inventory SET sold_count=(SELECT COUNT(*) FROM user_ufos WHERE user_ufos.ufo_id=ufo_inventory.ufo_id),
 remaining=MAX(0,supply_total-(SELECT COUNT(*) FROM user_ufos WHERE user_ufos.ufo_id=ufo_inventory.ufo_id));

CREATE TABLE IF NOT EXISTS nft_assets (
 id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL, source_type TEXT NOT NULL, source_id TEXT NOT NULL,
 title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'eligible', collection_address TEXT DEFAULT '', item_address TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, minted_at TEXT, UNIQUE(source_type,source_id)
);
-- Every past purchase is eligible for later manual conversion; nothing is minted now.
INSERT OR IGNORE INTO nft_assets(telegram_id,source_type,source_id,title,status)
SELECT p.telegram_id,'ufo_purchase',CAST(p.id AS TEXT),p.ufo_id || ' #' || p.serial_no,'eligible' FROM ufo_purchases p;

-- A previously recorded million-point best score also qualifies for the special reward.
INSERT OR IGNORE INTO nft_assets(telegram_id,source_type,source_id,title,status)
SELECT telegram_id,'million_score',CAST(telegram_id AS TEXT),'Million Score Champion','pending_review' FROM users WHERE best_score>=1000000;
