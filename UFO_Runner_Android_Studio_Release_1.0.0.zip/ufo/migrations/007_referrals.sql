-- Referral system: unique invite codes, qualified referrals, and limited UFO rewards.
-- A referred player qualifies only after a valid server-verified run reaches 1,000 points.
CREATE TABLE IF NOT EXISTS referral_codes (
  code TEXT PRIMARY KEY,
  referrer_id INTEGER NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS referral_edges (
  referred_id INTEGER PRIMARY KEY,
  referrer_id INTEGER NOT NULL,
  code TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  qualified_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_referral_edges_referrer ON referral_edges(referrer_id, qualified_at);
CREATE TABLE IF NOT EXISTS referral_reward_claims (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  referrer_id INTEGER NOT NULL,
  ufo_id TEXT NOT NULL,
  serial_no INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(referrer_id, ufo_id),
  UNIQUE(ufo_id, serial_no)
);
-- Latest owner-approved model supplies: first 50 of each model are reserved for referrals.
UPDATE ufo_inventory SET supply_total=200, remaining=MAX(0,200-sold_count) WHERE ufo_id='comet';
UPDATE ufo_inventory SET supply_total=150, remaining=MAX(0,150-sold_count) WHERE ufo_id='nova';
