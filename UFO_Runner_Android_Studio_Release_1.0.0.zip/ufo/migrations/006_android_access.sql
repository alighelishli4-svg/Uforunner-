-- Android guest sessions and one-time Telegram account linking.
-- Run ONCE on the existing production D1 database after migration 004 (and before migration 007).
CREATE TABLE IF NOT EXISTS android_sessions (
  token_hash TEXT PRIMARY KEY,
  telegram_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  revoked INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_android_sessions_player ON android_sessions(telegram_id);
CREATE TABLE IF NOT EXISTS android_link_codes (
  code_hash TEXT PRIMARY KEY,
  telegram_id INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_android_link_codes_expiry ON android_link_codes(expires_at);
INSERT OR IGNORE INTO settings(key,value) VALUES ('telegram_channel_url','');
