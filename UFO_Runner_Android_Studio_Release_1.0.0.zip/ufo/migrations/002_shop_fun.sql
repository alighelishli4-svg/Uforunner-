-- Run ONCE on an existing database (the one created by the first version):
--   npx wrangler d1 execute ufo-runner-db --remote --file=migrations/002_shop_fun.sql
ALTER TABLE users ADD COLUMN fun INTEGER DEFAULT 0;

CREATE TABLE IF NOT EXISTS user_ufos (
  telegram_id INTEGER NOT NULL,
  ufo_id TEXT NOT NULL,
  PRIMARY KEY (telegram_id, ufo_id)
);

CREATE TABLE IF NOT EXISTS fun_purchases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  charge_id TEXT NOT NULL UNIQUE,
  telegram_id INTEGER NOT NULL,
  stars INTEGER NOT NULL,
  fun INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  settled_at TEXT
);

INSERT OR IGNORE INTO settings(key, value) VALUES ('fun_enabled', '0');
