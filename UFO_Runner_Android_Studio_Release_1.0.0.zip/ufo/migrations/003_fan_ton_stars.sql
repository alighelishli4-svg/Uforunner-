-- Migration from the FUN/Blum version to FAN/TON + Stars-only features.
-- Run ONCE. SQLite cannot "ADD COLUMN IF NOT EXISTS", so a second run fails on the first line (that is safe).
-- Nothing is deleted: old FUN purchase records are kept in fun_purchases_archive and users.fun is left untouched.
ALTER TABLE users ADD COLUMN fan_balance INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN ton_address TEXT DEFAULT '';
ALTER TABLE fun_purchases RENAME TO fun_purchases_archive;
CREATE TABLE IF NOT EXISTS stars_purchases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  charge_id TEXT NOT NULL UNIQUE,
  telegram_id INTEGER NOT NULL,
  item TEXT NOT NULL,
  stars INTEGER NOT NULL,
  refunded INTEGER NOT NULL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
INSERT OR IGNORE INTO settings(key,value) VALUES
  ('fan_enabled','0'),
  ('stars_shop_enabled','0'),
  ('stars_laser_enabled','0'),
  ('stars_extra_life_enabled','0'),
  ('stars_laser','50'),
  ('stars_extra_life','75'),
  ('fan_decimals','9');
