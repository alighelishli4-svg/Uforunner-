import { DatabaseSync } from "node:sqlite";
import { readFileSync } from "node:fs";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import worker, { validateInitData } from "../src/index.js";

// --- minimal D1 shim on node:sqlite (supports ?N params, batch as one transaction) ---
const sqlite = new DatabaseSync(":memory:");
sqlite.exec(readFileSync(new URL("../schema.sql", import.meta.url), "utf8"));
sqlite.exec(readFileSync(new URL("../migrations/006_android_access.sql", import.meta.url), "utf8"));
sqlite.exec(readFileSync(new URL("../migrations/007_referrals.sql", import.meta.url), "utf8"));
function stmt(sql, args = []) {
  const order = [...sql.matchAll(/\?(\d+)/g)].map((m) => Number(m[1]) - 1);
  const plain = sql.replace(/\?\d+/g, "?");
  const vals = order.length ? order.map((i) => args[i]) : args;
  return {
    bind: (...a) => stmt(sql, a),
    first: async () => sqlite.prepare(plain).get(...vals) ?? null,
    all: async () => ({ results: sqlite.prepare(plain).all(...vals) }),
    run: async () => { const r = sqlite.prepare(plain).run(...vals); return { meta: { changes: Number(r.changes) } }; },
  };
}
const DB = {
  prepare: (s) => stmt(s),
  batch: async (list) => {
    sqlite.exec("BEGIN");
    try { for (const s of list) await s.run(); sqlite.exec("COMMIT"); } catch (e) { sqlite.exec("ROLLBACK"); throw e; }
  },
};
const BOT_TOKEN = "123456:TESTTOKEN";
const env = { DB, BOT_TOKEN, ADMIN_ID: "42", WEBHOOK_SECRET: "sec_123", BOT_USERNAME: "Ufo2026_game_bot", ASSETS: { fetch: async () => new Response("asset") } };

function makeInitData(user, authDate = Math.floor(Date.now() / 1000)) {
  const p = new URLSearchParams({ auth_date: String(authDate), query_id: "AAA", user: JSON.stringify(user) });
  const dcs = [...p.entries()].sort((a, b) => (a[0] < b[0] ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  p.set("hash", crypto.createHmac("sha256", secret).update(dcs).digest("hex"));
  return p.toString();
}
const call = async (path, body, method = "POST", extraHeaders = {}) => {
  const res = await worker.fetch(new Request("https://x.dev" + path, { method, body: body ? JSON.stringify(body) : undefined, headers: { "content-type": "application/json", ...extraHeaders } }), env);
  return { status: res.status, data: await res.json().catch(() => null) };
};
const sent = [];
globalThis.fetch = async (url, opts) => {
  const method = String(url).split("/").pop(); const body = JSON.parse(opts.body); sent.push({ method, body });
  return new Response(JSON.stringify({ ok: true, result: method === "createInvoiceLink" ? "https://t.me/$invoice123" : {} }));
};
const hook = (update, secret = "sec_123") => worker.fetch(new Request("https://x.dev/webhook", { method: "POST", headers: { "X-Telegram-Bot-Api-Secret-Token": secret }, body: JSON.stringify(update) }), env);
const admin = (text) => hook({ message: { text, chat: { id: 1 }, from: { id: 42 } } });
const lastText = () => sent.filter((s) => s.method === "sendMessage").at(-1).body.text;

const u = { id: 7, first_name: "Ali", username: "ali" };
const init = makeInitData(u);

// ---- auth
assert.equal((await validateInitData(init, env)).id, 7);
assert.equal((await call("/api/me", { init_data: init.replace("hash=", "hash=0") })).status, 401);
assert.equal((await call("/api/me", { init_data: makeInitData(u, 1000) })).status, 401);
console.log("ok auth");

// ---- me / start / finish (coins + anti-cheat)
let r = await call("/api/me", { init_data: init });
assert.equal(r.data.user.coins, 0); assert.equal(r.data.user.fun_balance, 0); assert.deepEqual(r.data.user.owned, ["scout"]);
assert.equal(r.data.user.selected_ufo, "scout"); assert.equal(r.data.config.ufos.length, 7);
assert.equal(r.data.fun.enabled, false);
const ufos = r.data.config.ufos;
for (let i = 1; i < ufos.length; i++) { assert.ok(ufos[i].speed > ufos[i - 1].speed && ufos[i].maneuver > ufos[i - 1].maneuver && ufos[i].price > ufos[i - 1].price); }
r = await call("/api/start", { init_data: init }); const runId = r.data.run_id;
r = await call("/api/finish", { init_data: init, run_id: runId, score: 10, coins: 999 });
assert.equal(r.data.valid, false);
assert.equal((await call("/api/finish", { init_data: init, run_id: runId, score: 10, coins: 1 })).status, 409);
r = await call("/api/start", { init_data: init });
r = await call("/api/finish", { init_data: init, run_id: r.data.run_id, score: 50, coins: 3 });
assert.equal(r.data.valid, true); assert.equal(r.data.user.coins, 3);
console.log("ok run/coins/anti-cheat");

// ---- referral codes: only new referred users count, qualification requires a valid 1,000-point run
let refInfo = await call("/api/referral", { init_data: init });
assert.equal(refInfo.status, 200); assert.match(refInfo.data.code, /^[A-F0-9]{10}$/);
assert.ok(refInfo.data.invite_url.includes(`ref_${refInfo.data.code}`));
for (let i = 0; i < 10; i++) {
  const friend = { id: 100 + i, first_name: `Friend${i}` };
  await hook({ message: { text: `/start ref_${refInfo.data.code}`, chat: { id: friend.id }, from: friend } });
  const friendInit = makeInitData(friend);
  const started = await call("/api/start", { init_data: friendInit });
  const finished = await call("/api/finish", { init_data: friendInit, run_id: started.data.run_id, score: 1000, coins: 0 });
  assert.equal(finished.data.valid, true);
}
refInfo = await call("/api/referral", { init_data: init });
assert.equal(refInfo.data.qualified_friends, 10);
assert.equal(refInfo.data.comet_unlocked, true); assert.equal(refInfo.data.nova_unlocked, true);
assert.deepEqual(sqlite.prepare("SELECT ufo_id FROM user_ufos WHERE telegram_id=7 ORDER BY ufo_id").all().map(x=>x.ufo_id), ["comet", "nova"]);
assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM referral_reward_claims WHERE referrer_id=7").get().n, 2);
console.log("ok referral: unique invite, 1,000-point qualification, Comet/Nova rewards");

// ---- coin upgrades + Stars-only premium features
assert.equal((await call("/api/upgrade", { init_data: init, key: "speed" })).status, 400);
sqlite.exec("UPDATE users SET coins=1000 WHERE telegram_id=7");
r = await call("/api/upgrade", { init_data: init, key: "speed" }); assert.equal(r.data.user.speed_level, 2); assert.equal(r.data.user.coins, 980);
assert.equal((await call("/api/upgrade", { init_data: init, key: "laser" })).status, 400);
sqlite.exec("UPDATE settings SET value='1' WHERE key IN ('stars_shop_enabled','stars_laser_enabled')");
r = await call("/api/stars/invoice", { init_data: init, item: "laser" }); assert.equal(r.status, 200);
console.log("ok upgrades + Stars separation");

// ---- Stars payment lifecycle: pay -> admin notified -> duplicate ignored -> already-owned -> list -> refund
const payUpdate = (charge, amount = 50, uid = 7) => ({ message: { chat: { id: uid }, from: { id: uid }, successful_payment: { currency: "XTR", total_amount: amount, invoice_payload: `star:laser:50:${uid}:abcd1234`, telegram_payment_charge_id: charge } } });
sent.length = 0; await hook(payUpdate("ch_1"));
assert.equal((await call("/api/me", { init_data: init })).data.user.laser, 1);
assert.ok(sent.some((x) => x.method === "sendMessage" && String(x.body.chat_id) === "42" && x.body.text.includes("New purchase")), "admin is told about every Stars purchase");
sent.length = 0; await hook(payUpdate("ch_1"));
assert.equal(sent.filter((x) => x.method === "sendMessage").length, 0, "same charge_id is processed once");
assert.equal((await call("/api/stars/invoice", { init_data: init, item: "laser" })).status, 409);
sent.length = 0; await hook(payUpdate("ch_bad", 1));
assert.ok(sent.some((x) => x.method === "sendMessage" && x.body.text.includes("Suspicious")), "mismatching amount is reported, not granted");
await admin("/purchases"); assert.ok(lastText().includes("ch_1"));
await admin("/refund nope"); assert.ok(lastText().includes("not found"));
await admin("/refund ch_1"); assert.ok(lastText().includes("Refunded"));
assert.ok(sent.some((x) => x.method === "refundStarPayment" && x.body.telegram_payment_charge_id === "ch_1" && x.body.user_id === 7));
assert.equal((await call("/api/me", { init_data: init })).data.user.laser, 0, "refund takes the item back");
await admin("/refund ch_1"); assert.ok(lastText().includes("Already refunded"));
assert.equal((await call("/api/stars/invoice", { init_data: init, item: "laser" })).status, 200);
console.log("ok Stars purchase / duplicate / refund");

// ---- Stars admin input validation + single sale switch per item
for (const bad of ["abc", "0", "-5", "1.5", "99999", ""]) { await admin("/stars_laser " + bad); assert.ok(lastText().startsWith("Example"), "rejects " + bad); }
await admin("/stars_life 80"); assert.equal((await call("/api/me", { init_data: init })).data.stars.items.extra_life.stars, 80);
await admin("/stars_laser 50");
await hook({ callback_query: { id: "cb1", from: { id: 42 }, data: "tg:stars_laser_enabled", message: { chat: { id: 1 }, message_id: 9 } } });
assert.equal((await call("/api/me", { init_data: init })).data.stars.items.laser.enabled, false, "panel button toggles the laser sale switch");
await hook({ callback_query: { id: "cb2", from: { id: 42 }, data: "tg:stars_laser_enabled", message: { chat: { id: 1 }, message_id: 9 } } });
assert.equal((await call("/api/me", { init_data: init })).data.stars.items.laser.enabled, true);
console.log("ok Stars admin validation + switches");

// ---- Million Score NFT eligibility is server-recorded, never auto-minted
r = await call("/api/start", { init_data: init });
sqlite.prepare("UPDATE game_runs SET started_at=? WHERE run_id=?").run(Date.now()/1000 - 1300, r.data.run_id);
r = await call("/api/finish", { init_data: init, run_id: r.data.run_id, score: 1_000_000, coins: 100 });
assert.equal(r.data.valid, true); assert.equal(r.data.user.million_nft_eligible, true);
assert.equal(sqlite.prepare("SELECT status FROM nft_assets WHERE source_type='million_score'").get().status, "pending_review");
console.log("ok Million Score NFT eligibility (not minted)");

// ---- FUN purchases stay fail-closed: no off-chain balance can masquerade as TON payment
sqlite.exec("UPDATE users SET fun_balance=300 WHERE telegram_id=7");
await admin("/fun_on"); await admin("/fun_token EQlaunchedToken"); await admin("/fun_sales_on");
assert.ok(lastText().includes("cannot be enabled yet"), "admin cannot enable sales before real TON settlement exists");
r = await call("/api/ufo/buy", { init_data: init, ufo_id: "comet" }); assert.equal(r.status, 503);
assert.equal(sqlite.prepare("SELECT fun_balance FROM users WHERE telegram_id=7").get().fun_balance, 300, "FUN database balance is never debited as payment");
assert.equal(sqlite.prepare("SELECT remaining FROM ufo_inventory WHERE ufo_id='comet'").get().remaining, 199, "locked purchase does not reserve stock after one referral reward");
assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM ufo_purchases WHERE source='primary'").get().n, 0);
assert.equal((await call("/api/me", { init_data: init })).data.fun.salesEnabled, false);
console.log("ok FUN shop locked pending real cannot be enabled yet");

// ---- Android guest session, shared D1 data, Telegram account linking and channel reminder
let ar = await call("/api/android/register", {});
assert.equal(ar.status, 200); assert.equal(ar.data.token.length, 64);
const guestPlayerId = ar.data.player_id;
const androidHeaders = { Authorization: `Bearer ${ar.data.token}` };
ar = await call("/api/me", {}, "POST", androidHeaders);
assert.equal(ar.status, 200); assert.equal(ar.data.user.best_score, 0);
sqlite.prepare("UPDATE users SET coins=125,best_score=321 WHERE telegram_id=?").run(guestPlayerId);
ar = await call("/api/android/link-code", {}, "POST", androidHeaders);
assert.equal(ar.status, 200); assert.equal(ar.data.code.length, 12);
sent.length = 0;
await hook({ message: { text: `/link ${ar.data.code}`, chat: { id: 7 }, from: { id: 7, first_name: "Ali", username: "ali" } } });
assert.ok(lastText().includes("متصل شد"));
ar = await call("/api/me", {}, "POST", androidHeaders);
assert.equal(ar.status, 200); assert.equal(ar.data.user.best_score, 1000000); assert.equal(ar.data.user.coins, 1205);
assert.equal(sqlite.prepare("SELECT COUNT(*) n FROM users WHERE telegram_id=?").get(guestPlayerId).n, 0);
await admin("/channel https://t.me/UFOTestChannel");
ar = await call("/api/public-config", null, "GET");
assert.equal(ar.data.channel_url, "https://t.me/UFOTestChannel");
await admin("/channel off");
assert.equal((await call("/api/public-config", null, "GET")).data.channel_url, "");
console.log("ok Android guest auth + Telegram linking + shared account + channel config");

// ---- no Stars -> FUN conversion endpoint
assert.equal((await call("/api/fun/invoice", { init_data: init, pack: 0 })).status, 404);

// ---- bot basics
sent.length = 0;
await hook({ message: { text: "/start", chat: { id: 1 }, from: { id: 7 } } });
assert.ok(sent.at(-1).body.reply_markup.inline_keyboard[0][0].web_app.url === "https://x.dev/");
sent.length = 0; await hook({ message: { text: "/fun_on", chat: { id: 1 }, from: { id: 7 } } }); assert.equal(sent.length, 0);   // non-admin ignored
assert.equal((await call("/api/me", { init_data: init })).data.fun.enabled, true);
await admin("/admin"); assert.ok(lastText().includes("کاربران: 1")); assert.ok(lastText().includes("FUN"));
await hook({ message: { text: "/paysupport", chat: { id: 1 }, from: { id: 7 } } }); assert.ok(lastText().includes("Payment"));
assert.equal((await hook({}, "wrong")).status, 403);
assert.equal((await call("/setup?key=bad", null, "GET")).status, 403);
r = await call("/setup?key=sec_123", null, "GET"); assert.equal(r.status, 200);
assert.deepEqual(sent.find((s) => s.method === "setWebhook").body.allowed_updates, ["message", "callback_query", "pre_checkout_query"]);
r = await call("/api/leaderboard", null, "GET"); assert.equal(r.data[0].telegram_id, undefined);
console.log("ALL TESTS PASSED");
