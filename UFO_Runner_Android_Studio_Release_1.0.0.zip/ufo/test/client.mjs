// Runs the real client modules against stub DOM/canvas: catches runtime errors in the game loop, shop and drawing code.
import assert from "node:assert/strict";

const grad = { addColorStop() {} };
const ctxStub = new Proxy({}, { get: (t, k) => (k in t ? t[k] : /^create/.test(k) ? () => grad : k === "measureText" ? () => ({ width: 10 }) : () => {}), set: (t, k, v) => ((t[k] = v), true) });
class CanvasRenderingContext2D {}                                    // only for the roundRect polyfill check
const els = {};
const mk = (id) => ({ id, style: {}, dataset: {}, textContent: "", disabled: false, className: "", children: [], width: 300, height: 150,
  classList: { _s: new Set(), add(c) { this._s.add(c); }, remove(c) { this._s.delete(c); }, toggle(c, on) { on ? this._s.add(c) : this._s.delete(c); }, contains(c) { return this._s.has(c); } },
  appendChild(c) { this.children.push(c); return c; }, addEventListener() {}, getContext: () => ctxStub,
  getBoundingClientRect: () => ({ width: 360, height: 600 }), clientWidth: 360, clientHeight: 600,
  _html: "", get innerHTML() { return this._html; }, set innerHTML(v) { this._html = v; this.children = []; } });
const el = (id) => (els[id] ??= mk(id));
const docHandlers = {}; let now = 0; const frames = []; const calls = [];
const USER = { best_score: 0, coins: 700, fun_balance: 500, language: "en", speed_level: 2, maneuver_level: 3, extra_life: 0, laser: 1, selected_ufo: "aurora", owned: ["scout", "aurora", "comet"] };
const UFOS = ["scout", "comet", "nova", "phantom", "vortex", "eclipse", "aurora"].map((id, i) => ({ id, speed: i * .1, maneuver: i * 70, price: i * 100, name: { en: id, fa: id } }));
const CONFIG = { max_level: 10, laser_cost: 300, costs: [20, 40, 60, 80, 100, 120, 140, 160, 180], ufos: UFOS };
Object.assign(globalThis, {
  CanvasRenderingContext2D, devicePixelRatio: 2, addEventListener() {},
  document: { getElementById: el, querySelector: (q) => el(q), querySelectorAll: () => [el("home"), el("shop"), el("gameover")], createElement: (t) => mk(t),
    addEventListener: (ev, f) => (docHandlers[ev] = f), documentElement: {} },
  requestAnimationFrame: (f) => { frames.push(f); return frames.length; },
  window: { Telegram: { WebApp: { ready() {}, expand() {}, initData: "x=1", openInvoice: (l, cb) => { calls.push("invoice:" + l); cb("paid"); }, openLink() {} } } },
  fetch: async (url, o) => {
    calls.push(url); const b = JSON.parse(o.body);
    const base = { user: USER, settings: { fun_enabled: true, stars_shop_enabled: true, stars_laser_enabled: true, stars_extra_life_enabled: true }, fun: { enabled: true, tokenAddress: "EQtest", decimals: 9, buyUrl: "", note: "", network: "TON" }, stars: { enabled: true, items: { laser: { stars: 50, enabled: true }, extra_life: { stars: 75, enabled: true } } }, config: CONFIG };
    const data = url.includes("finish") ? { valid: true, user: USER } : url.includes("invoice") ? { link: "https://t.me/$x" } : url.includes("start") ? { run_id: "r", ...base } : { ok: true, ...base };
    return { ok: true, json: async () => data, text: async () => "" };
  },
});
const realNow = performance.now.bind(performance);
globalThis.performance = { now: () => now };
const tick = (n = 1) => { for (let i = 0; i < n; i++) { now += 16; const f = frames.shift(); if (f) f(now); } };

await import("../public/js/main.js");
const g = globalThis.__ufo;
await new Promise((r) => setTimeout(r, 30));            // boot: /api/me
tick(5);                                                 // idle sky (day/night schedule runs here too)

// ---- shop renders every UFO and every UFO design draws without error
el("shopBtn").onclick(); tick(3);
assert.equal(el("shopList").children.length, 7);
for (const u of UFOS) g.drawUfo(ctxStub, u.id, 1.3, 0.5);
for (const t of g.JET_TYPES) g.drawJet(ctxStub, { x: 0, y: 0, type: t }, 0.7);
for (const [type, d] of Object.entries(g.OBSTACLES)) g.drawObstacle(ctxStub, { type, x: 10, y: 10, w: d.w, h: d.h, sc: 1, phase: 1, rot: 1, shape: Array(9).fill(1) }, 0.9);
assert.equal(Object.keys(g.OBSTACLES).length, 6);
assert.equal(g.OBSTACLES.mine.destructible, false);
assert.ok(Object.entries(g.OBSTACLES).filter(([k, d]) => d.destructible).length === 5);
assert.equal(g.JET_TYPES.join(), "F-14,GENERIC_A,GENERIC_B");
el("shopBack").onclick();

// ---- play: keep the UFO hovering with bang-bang control at high score so every obstacle type appears
await g.start(); tick(1);
assert.ok(g.running);
g.setScore(12000);
const obs = new Set(), jets = new Set(); let sawBanner = false, sawNight = false, frameCount = 0;
let restarts = 0;
for (let i = 0; i < 6000; i++) {
  if (!g.running) { await new Promise((r) => setTimeout(r, 0)); await g.start(); g.setScore(12000); restarts++; tick(1); continue; }   // bot isn't perfect: restart after a crash
  const hold = g.player.y > 300; docHandlers.keydown?.({ key: "ArrowUp", preventDefault() {} }); if (!hold) docHandlers.keyup?.({ key: "ArrowUp" });
  tick(1); frameCount++;
  g.obstacles.forEach((o) => obs.add(o.type)); g.aircraft.forEach((a) => jets.add(a.type));
  sawBanner ||= !!g.banner; sawNight ||= g.night > 0.5;
  if (g.score < 12000) g.setScore(12000);
}
console.log(`ran ${frameCount} frames | obstacle types: ${[...obs].sort().join(",")} | jets: ${[...jets].sort().join(",")} | mine banner: ${sawBanner} | night seen: ${sawNight} | restarts: ${restarts}`);
assert.ok(frameCount > 300, "game should survive a while");
assert.equal(obs.size, 6, "all six obstacle types should have spawned");
assert.equal(jets.size, 3, "all three aircraft types should have spawned");

// ---- manual laser: no auto-fire; right side of the screen fires; left side thrusts; cooldown applies
const hold = () => docHandlers.keydown?.({ key: "ArrowUp", preventDefault() {} });
const release = () => docHandlers.keyup?.({ key: "ArrowUp" });
const endRun = async () => { if (g.running) { g.run.lives = 0; g.run.invuln = 0; g.player.y = 2; tick(1); } await new Promise((r) => setTimeout(r, 0)); };
const steer = () => { g.player.y > 300 ? hold() : release(); };
USER.laser = 1; USER.extra_life = 0;
await g.start(); tick(1); assert.ok(g.running && g.run.laser); g.run.invuln = 100;
let autoFired = false;
for (let i = 0; i < 200 && g.running; i++) { steer(); tick(1); if (g.beam) autoFired = true; }
assert.equal(autoFired, false, "laser must not fire by itself any more");
assert.ok(g.run.laserCd <= 0, "cooldown is over after a couple of seconds");
g.onPointerDown(11, 0.25); assert.equal(g.beam, null, "left side = thrust, not fire"); g.onPointerUp(11);
g.run.laserCd = 0; g.onPointerDown(12, 0.9); assert.ok(g.beam, "right side fires"); assert.ok(g.run.laserCd > 0.9);
assert.equal(g.tryFireLaser(), false, "cooldown blocks a second shot");
for (let i = 0; i < 90; i++) { steer(); tick(1); }
assert.equal(g.tryFireLaser(), true, "ready again after the cooldown");
// armored mine survives a shot, a destructible obstacle does not
if (g.running) {
  const mine = g.spawnObstacle(0, 360, 600); mine.type = "mine"; mine.x = g.player.x + 150; mine.y = g.player.y; g.obstacles.push(mine);
  const rock = g.spawnObstacle(0, 360, 600); rock.type = "asteroid"; rock.x = g.player.x + 200; rock.y = g.player.y; g.obstacles.push(rock);
  g.run.laserCd = 0; g.tryFireLaser();
  assert.ok(g.obstacles.includes(mine), "armored mine is not destroyed by laser"); assert.ok(!g.obstacles.includes(rock), "asteroid is destroyed");
}
// without the laser the whole screen is thrust and nothing fires
USER.laser = 0; await endRun(); await g.start(); tick(1);
assert.equal(g.run.laser, false); g.onPointerDown(13, 0.9); assert.equal(g.beam, null); assert.equal(g.tryFireLaser(), false);
g.onPointerUp(13);

// ---- extra life: survives exactly one crash per run, protected for a moment, then normal rules
USER.extra_life = 1; await endRun(); await g.start(); tick(1);
assert.equal(g.run.lives, 1);
const crash = () => { const o = g.spawnObstacle(0, 360, 600); o.type = "asteroid"; o.x = g.player.x; o.y = g.player.y; g.obstacles.push(o); return o; };
const first = crash(); tick(1);
assert.ok(g.running, "first crash is survived"); assert.equal(g.run.lives, 0); assert.ok(g.run.invuln > 0); assert.ok(!g.obstacles.includes(first));
crash(); tick(1); assert.ok(g.running, "protected right after losing the life");
for (let i = 0; i < 160 && g.running; i++) { steer(); tick(1); }       // let the protection run out
assert.ok(g.running && g.run.invuln <= 0, "protection ended");
crash(); tick(1); assert.equal(g.running, false, "second crash ends the run");
// wall: extra life bounces the UFO back inside instead of ending the run
USER.extra_life = 1; await endRun(); await g.start(); tick(1);
g.player.y = 5; tick(1); assert.ok(g.running, "wall hit survived with extra life"); assert.ok(g.player.y >= 26); assert.equal(g.run.lives, 0);
for (let i = 0; i < 160 && g.running; i++) { steer(); tick(1); }
g.player.y = 5; tick(1); assert.equal(g.running, false, "wall hit without life ends the run");
// owned items stay visible even when the admin stops selling them
USER.extra_life = 1; USER.laser = 1; el("home").classList.add("hidden");
console.log("manual laser + extra life OK");
console.log("client OK");
