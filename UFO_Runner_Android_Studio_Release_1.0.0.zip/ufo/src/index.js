// UFO Runner — Cloudflare Worker entry: routes only. Logic lives in src/modules, src/bot, src/lib.
import { HttpError, json, readBody } from "./lib/http.js";
import { validateInitData } from "./lib/auth.js";
import { upsertUser } from "./lib/db.js";
import * as game from "./modules/game.js";
import * as upgrades from "./modules/upgrades.js";
import * as shop from "./modules/shop.js";
import * as fun from "./modules/fun.js";
import * as stars from "./modules/stars.js";
import { handleUpdate } from "./bot/handlers.js";
import { tgCall } from "./bot/telegram.js";
import { registerAndroid, validateAndroidToken, createAndroidLinkCode } from "./lib/android-auth.js";
import { referralInfo } from "./modules/referrals.js";

export { validateInitData };

// path -> handler(env, tg, body). Add a line here to add an endpoint.
const ROUTES = {
  "/api/android/link-code": async (env, tg) => createAndroidLinkCode(env, tg.id),
  "/api/referral": referralInfo,
  "/api/me": game.me,
  "/api/start": game.start,
  "/api/finish": game.finish,
  "/api/upgrade": upgrades.upgrade,
  "/api/ufo/buy": shop.buyUfo,
  "/api/ufo/select": shop.selectUfo,
  "/api/fun/wallet": fun.wallet,
  "/api/fun/connect": fun.connectWallet,
  "/api/fun/verify-deposit": fun.verifyDeposit,
  "/api/stars/invoice": stars.createInvoice,
  "/api/language": async (env, tg, body) => {
    if (!["en", "fa"].includes(body.language)) throw new HttpError(400, "Unsupported language");
    if (!tg.is_android) await upsertUser(env, tg);
    await env.DB.prepare("UPDATE users SET language=?1 WHERE telegram_id=?2").bind(body.language, tg.id).run();
    return { ok: true };
  },
};

async function handleApi(request, env, path) {
  if (path === "/api/android/register" && request.method === "POST") return json(await registerAndroid(env));
  if (path === "/api/public-config" && request.method === "GET") {
    const row = await env.DB.prepare("SELECT value FROM settings WHERE key='telegram_channel_url'").first();
    return json({ channel_url: row?.value || "" });
  }
  if (path === "/api/leaderboard" && request.method === "GET") {
    const { results } = await env.DB.prepare("SELECT first_name, username, best_score FROM users ORDER BY best_score DESC LIMIT 20").all();
    return json(results);
  }
  const handler = ROUTES[path];
  if (!handler) throw new HttpError(404, "Not found");
  if (request.method !== "POST") throw new HttpError(405, "Method not allowed");
  const body = await readBody(request);
  const auth = request.headers.get("Authorization") || "";
  const tg = auth.startsWith("Bearer ")
    ? await validateAndroidToken(request, env)
    : await validateInitData(body.init_data, env);
  return json(await handler(env, tg, body));
}

async function handleSetup(env, url) {
  if (!env.WEBHOOK_SECRET || url.searchParams.get("key") !== env.WEBHOOK_SECRET) throw new HttpError(403, "Forbidden");
  const webapp = (env.WEBAPP_URL || url.origin).replace(/\/$/, "") + "/";
  return json({
    webhook: await tgCall(env, "setWebhook", {
      url: `${url.origin}/webhook`, secret_token: env.WEBHOOK_SECRET,
      allowed_updates: ["message", "callback_query", "pre_checkout_query"],
    }),
    menu: await tgCall(env, "setChatMenuButton", { menu_button: { type: "web_app", text: "🎮 Play", web_app: { url: webapp } } }),
    commands: await tgCall(env, "setMyCommands", {
      commands: [{ command: "start", description: "Play" }, { command: "game", description: "Open game" }, { command: "paysupport", description: "Payment help" }],
    }),
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    try {
      if (url.pathname === "/webhook" && request.method === "POST") {
        if (request.headers.get("X-Telegram-Bot-Api-Secret-Token") !== env.WEBHOOK_SECRET) throw new HttpError(403, "Forbidden");
        await handleUpdate(env, await request.json(), url.origin);
        return new Response("ok");
      }
      if (url.pathname === "/setup") return await handleSetup(env, url);
      if (url.pathname === "/tonconnect-manifest.json") {
        return json({ url: url.origin, name: "UFO Runner", iconUrl: `${url.origin}/icon.svg` });
      }
      if (url.pathname.startsWith("/api/")) return await handleApi(request, env, url.pathname);
      return env.ASSETS.fetch(request);
    } catch (e) {
      if (e instanceof HttpError) return json({ error: e.message }, e.status);
      console.error(e);
      if (url.pathname === "/webhook") return new Response("ok");   // never make Telegram retry forever
      return json({ error: "Server error" }, 500);
    }
  },
};
