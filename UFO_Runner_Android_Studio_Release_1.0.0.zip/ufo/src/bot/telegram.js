export async function tgCall(env, method, payload) {
  const res = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload),
  });
  return res.json();
}
export const isAdmin = (env, id) => !!env.ADMIN_ID && String(id) === String(env.ADMIN_ID).trim();
export const notifyAdmin = (env, text, extra = {}) =>
  env.ADMIN_ID ? tgCall(env, "sendMessage", { chat_id: String(env.ADMIN_ID).trim(), text, ...extra }) : null;
