// Admin panel + commands (only the ADMIN_ID user reaches this file, see handlers.js).
import { FLAGS } from "../config/constants.js";
import { UFOS } from "../config/catalog.js";
import { allSettings, setSetting, flag, funConfig, starsConfig } from "../lib/settings.js";
import { refundStars, recentPurchases } from "../modules/stars.js";
import { tgCall } from "./telegram.js";

// ---------- panel ----------
export async function adminPanel(env) {
  const [users, runs, runs24, coins, top, map] = await Promise.all([
    env.DB.prepare("SELECT COUNT(*) n FROM users").first(),
    env.DB.prepare("SELECT COUNT(*) n,SUM(valid) ok FROM game_runs WHERE ended_at IS NOT NULL").first(),
    env.DB.prepare("SELECT COUNT(*) n FROM game_runs WHERE started_at>?1").bind(Date.now() / 1000 - 86400).first(),
    env.DB.prepare("SELECT COALESCE(SUM(coins),0) held,COALESCE(SUM(total_coins),0) earned,COALESCE(SUM(fun_balance),0) fun FROM users").first(),
    env.DB.prepare("SELECT first_name,username,best_score FROM users ORDER BY best_score DESC LIMIT 5").all(),
    allSettings(env),
  ]);
  const topLines = top.results
    .map((u, i) => `${i + 1}. ${u.first_name || u.username || "?"}${u.username ? " @" + u.username : ""} — ${u.best_score}`)
    .join("\n") || "—";
  const text = `🛠 پنل ادمین UFO Runner

👥 کاربران: ${users.n}
🎮 بازی‌های ۲۴ ساعت اخیر: ${runs24.n}
✅ بازی‌های تمام‌شده: ${runs.n} (معتبر: ${runs.ok || 0})
🪙 سکه: ${coins.held} | کل: ${coins.earned}
💎 FUN ثبت‌شده: ${coins.fun}

🏆 برترین‌ها:
${topLines}

💎 /fun | ⭐ /stars | قیمت یوفو: /ufo_price`;
  const keyboard = Object.entries(FLAGS).map(([k, label]) => [
    { text: `${flag(map, k) ? "✅" : "❌"} ${label}`, callback_data: `tg:${k}` },
  ]);
  return { text, reply_markup: { inline_keyboard: keyboard } };
}

export async function handleAdminCallback(env, cq) {
  if (cq.data?.startsWith("tg:")) {
    const key = cq.data.slice(3);
    if (key in FLAGS) {
      const next = flag(await allSettings(env), key) ? 0 : 1;
      await setSetting(env, key, next);
      if (key === "fun_enabled" && next === 0) await setSetting(env, "fun_sales_enabled", 0);
    }
  }
  const panel = await adminPanel(env);
  if (cq.message) {
    await tgCall(env, "editMessageText", { chat_id: cq.message.chat.id, message_id: cq.message.message_id, ...panel });
  }
  await tgCall(env, "answerCallbackQuery", { callback_query_id: cq.id });
}

// ---------- commands ----------
const reply = (env, msg, text) => tgCall(env, "sendMessage", { chat_id: msg.chat.id, text });
const save = (env, msg, key, value, okText = "✅ saved") => setSetting(env, key, value).then(() => reply(env, msg, okText));

// Stars price: whole number of ⭐ between 1 and 10000.
function parseStars(args) {
  const n = Number(String(args).trim());
  return Number.isInteger(n) && n >= 1 && n <= 10000 ? n : null;
}

export async function handleAdminCommand(env, msg, cmd, args) {
  switch (cmd) {
    case "/channel": {
      const value = args.trim();
      if (!value) {
        const row = await env.DB.prepare("SELECT value FROM settings WHERE key='telegram_channel_url'").first();
        return reply(env, msg, `Channel link: ${row?.value || "not set"}\nSet: /channel https://t.me/yourchannel\nDisable: /channel off`);
      }
      if (value.toLowerCase() === "off") return save(env, msg, "telegram_channel_url", "", "⛔ Channel reminder disabled");
      if (!/^https:\/\/(t\.me|telegram\.me)\/[A-Za-z0-9_+/?=-]+$/.test(value)) return reply(env, msg, "Use a public Telegram channel link, e.g. https://t.me/yourchannel");
      return save(env, msg, "telegram_channel_url", value, "✅ Channel reminder link saved");
    }
    case "/admin": {
      const panel = await adminPanel(env);
      return tgCall(env, "sendMessage", { chat_id: msg.chat.id, ...panel });
    }

    // ----- FUN / TON -----
    case "/fun": return reply(env, msg, await funPanel(env));
    case "/fun_on": return save(env, msg, "fun_enabled", 1, "✅ FUN/TON enabled");
    case "/fun_off": {
      await setSetting(env, "fun_enabled", 0);
      await setSetting(env, "fun_sales_enabled", 0);
      return reply(env, msg, "⛔ FUN/TON disabled; in-game sales are also locked");
    }
    case "/fun_sales_on": {
      return reply(env, msg, "⛔ FUN UFO sales cannot be enabled yet. The game is fail-closed until the real Jetton payment flow and server-side TON transaction verification are configured and tested. No database FUN balance can be used as payment.");
    }
    case "/fun_sales_off": return save(env, msg, "fun_sales_enabled", 0, "⛔ In-game FUN UFO sales disabled");
    case "/fun_token": return save(env, msg, "fun_token_address", args.trim(), "✅ FUN token address saved");
    case "/fun_decimals": {
      const n = Number(args);
      if (!Number.isInteger(n) || n < 0 || n > 18) return reply(env, msg, "Invalid decimals");
      return save(env, msg, "fun_decimals", n);
    }
    case "/fun_buy_url": {
      const v = args.trim();
      if (v !== "-" && !/^https:\/\/\S+$/.test(v)) return reply(env, msg, "Use https:// URL or -");
      return save(env, msg, "fun_buy_url", v === "-" ? "" : v);
    }
    case "/fun_note": return save(env, msg, "fun_note", args.trim() === "-" ? "" : args.trim().slice(0, 300));

    // ----- Stars (laser / extra life) -----
    case "/stars": return reply(env, msg, await starsPanel(env));
    case "/stars_on": return save(env, msg, "stars_shop_enabled", 1, "✅ Stars shop enabled");
    case "/stars_off": return save(env, msg, "stars_shop_enabled", 0, "⛔ Stars shop disabled");
    case "/stars_laser": {
      const n = parseStars(args);
      return n ? save(env, msg, "stars_laser", n) : reply(env, msg, "Example: /stars_laser 50  (whole number, 1–10000)");
    }
    case "/stars_life": {
      const n = parseStars(args);
      return n ? save(env, msg, "stars_extra_life", n) : reply(env, msg, "Example: /stars_life 75  (whole number, 1–10000)");
    }
    case "/stars_laser_on": return save(env, msg, "stars_laser_enabled", 1, "✅ enabled");
    case "/stars_laser_off": return save(env, msg, "stars_laser_enabled", 0, "⛔ disabled");
    case "/stars_life_on": return save(env, msg, "stars_extra_life_enabled", 1, "✅ enabled");
    case "/stars_life_off": return save(env, msg, "stars_extra_life_enabled", 0, "⛔ disabled");
    case "/purchases": return reply(env, msg, await recentPurchases(env));
    case "/refund": return reply(env, msg, await refundStars(env, args.trim()));

    // ----- UFO prices (FUN) -----
    case "/ufo_price": {
      const [id, price] = args.trim().split(/\s+/), n = Number(price);
      if (!UFOS.some((u) => u.id === id && u.price > 0) || !Number.isInteger(n) || n < 1) return reply(env, msg, "Example: /ufo_price comet 120");
      let prices = {};
      try { prices = JSON.parse((await allSettings(env)).ufo_prices || "{}"); } catch {}
      prices[id] = n;
      return save(env, msg, "ufo_prices", JSON.stringify(prices), `✅ ${id} = ${n} FUN`);
    }
  }
  return false;
}

async function funPanel(env) {
  const c = funConfig(await allSettings(env));
  return `💎 FUN / TON
فعال‌سازی تنظیمات: ${c.enabled ? "✅" : "❌"}
فروش داخل بازی: ${c.salesEnabled ? "✅" : "❌"}
Contract: ${c.tokenAddress || "—"}
Decimals: ${c.decimals}
Buy URL: ${c.buyUrl || "—"}

/fun_on /fun_off
/fun_sales_on (currently locked until on-chain payment verification is deployed) /fun_sales_off
/fun_token <TON jetton address>
/fun_decimals 9
/fun_buy_url https://...
/fun_note متن`;
}

async function starsPanel(env) {
  const c = starsConfig(await allSettings(env));
  return `⭐ Stars Shop
فعال: ${c.enabled ? "✅" : "❌"}
Laser: ${c.items.laser.enabled ? c.items.laser.stars + " ⭐" : "خاموش"}
Extra Life: ${c.items.extra_life.enabled ? c.items.extra_life.stars + " ⭐" : "خاموش"}

/stars_on /stars_off
/stars_laser 50
/stars_life 75
/stars_laser_on /stars_laser_off
/stars_life_on /stars_life_off
/purchases  (آخرین خریدها + شناسه)
/refund <charge_id>  (بازگشت ⭐ و لغو قابلیت)`;
}
