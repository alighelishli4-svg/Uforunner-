import { isAdmin, tgCall } from "./telegram.js";
import { handleAdminCommand, handleAdminCallback } from "./admin.js";
import { handlePreCheckout, handleSuccessfulPayment } from "../modules/stars.js";
import { linkAndroidAccount } from "../lib/android-auth.js";
import { recordReferral } from "../modules/referrals.js";
import { upsertUser } from "../lib/db.js";

export async function handleUpdate(env, update, origin) {
  const webapp = (env.WEBAPP_URL || origin).replace(/\/$/, "") + "/";

  if (update.pre_checkout_query) return handlePreCheckout(env, update.pre_checkout_query);

  if (update.callback_query) {
    const cq = update.callback_query;
    if (!isAdmin(env, cq.from.id)) {
      await tgCall(env, "answerCallbackQuery", { callback_query_id: cq.id, text: "Admin only", show_alert: true });
      return;
    }
    return handleAdminCallback(env, cq);
  }

  const msg = update.message;
  if (!msg) return;
  if (msg.successful_payment) return handleSuccessfulPayment(env, msg);
  if (!msg.text) return;

  const [rawCmd, ...rest] = msg.text.split(/\s+/);
  const cmd = rawCmd.split("@")[0];
  const args = msg.text.slice(rawCmd.length).trim();

  if (cmd === "/link") {
    try {
      await linkAndroidAccount(env, msg.from, args.trim().toUpperCase());
      await tgCall(env, "sendMessage", { chat_id: msg.chat.id, text: "✅ حساب اندروید به حساب تلگرام متصل شد. اطلاعات بازی اکنون مشترک است." });
    } catch (e) {
      await tgCall(env, "sendMessage", { chat_id: msg.chat.id, text: `❌ ${e.message || "کد اتصال نامعتبر است."}` });
    }
    return;
  }

  if (cmd === "/start" || cmd === "/game") {
    if (cmd === "/start") {
      const existed = await env.DB.prepare("SELECT telegram_id FROM users WHERE telegram_id=?1").bind(msg.from.id).first();
      await upsertUser(env, msg.from);
      if (!existed && args.startsWith("ref_")) await recordReferral(env, msg.from.id, args.slice(4));
    }
    await tgCall(env, "sendMessage", {
      chat_id: msg.chat.id,
      text: "🛸 UFO RUNNER\n\nCome on, let's have some fun! Dodge, collect coins, upgrade your UFO and chase 1,000,000 points.",
      reply_markup: { inline_keyboard: [[{ text: "🎮 PLAY", web_app: { url: webapp } }]] },
    });
  } else if (cmd === "/paysupport") {      // Telegram requires bots that take Stars to answer this
    await tgCall(env, "sendMessage", { chat_id: msg.chat.id, text: "Payment problem? Write your issue and your Telegram Stars payment details here and the admin will help you." });
  } else if (isAdmin(env, msg.from.id)) {  // everyone else is ignored silently
    await handleAdminCommand(env, msg, cmd, args);
  }
}
