import { MAX_LEVEL, MAX_SCORE, upgradeCost } from "../config/constants.js";
import { publicUser } from "../lib/db.js";
import { allSettings, publicFlags, funConfig, starsConfig, ufoCatalog } from "../lib/settings.js";
export async function clientState(env, id) {
  const map = await allSettings(env), catalog = ufoCatalog(map);
  const inventory = await env.DB.prepare("SELECT ufo_id,remaining,sold_count FROM ufo_inventory").all();
  const stocks = Object.fromEntries(inventory.results.map((r) => [r.ufo_id, r]));
  return {
    user: await publicUser(env, id), settings: publicFlags(map), fun: funConfig(map), stars: starsConfig(map),
    config: { max_level: MAX_LEVEL, max_score: MAX_SCORE,
      costs: Array.from({ length: MAX_LEVEL - 1 }, (_, i) => upgradeCost(i + 1)),
      ufos: catalog.map((u) => ({ ...u, remaining: u.supply === null ? null : (stocks[u.id]?.remaining ?? u.supply), sold_count: stocks[u.id]?.sold_count ?? 0 })),
    },
  };
}
