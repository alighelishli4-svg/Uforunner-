import { MAX_SCORE, COINS_PER_SEC_CAP, COINS_RUN_SLACK } from "../config/constants.js";
import { HttpError } from "../lib/http.js";
import { upsertUser, publicUser } from "../lib/db.js";
import { clientState } from "./state.js";
import { qualifyReferral } from "./referrals.js";

export async function me(env, tg) {
  if (!tg.is_android) await upsertUser(env, tg);
  return clientState(env, tg.id);
}

export async function start(env, tg) {
  if (!tg.is_android) await upsertUser(env, tg);
  const runId = crypto.randomUUID().replaceAll("-", "");
  await env.DB.prepare("INSERT INTO game_runs(run_id, telegram_id, started_at) VALUES(?1, ?2, ?3)")
    .bind(runId, tg.id, Date.now() / 1000).run();
  return { run_id: runId, ...(await clientState(env, tg.id)) };
}

export async function finish(env, tg, body) {
  const score = body.score, coins = body.coins ?? 0;
  if (!Number.isInteger(score) || score < 0 || score > MAX_SCORE) throw new HttpError(400, "Bad score");
  if (!Number.isInteger(coins) || coins < 0 || coins > 100000) throw new HttpError(400, "Bad coins");
  if (typeof body.run_id !== "string") throw new HttpError(400, "Bad run");

  const run = await env.DB.prepare("SELECT started_at, ended_at FROM game_runs WHERE run_id=?1 AND telegram_id=?2")
    .bind(body.run_id, tg.id).first();
  if (!run) throw new HttpError(404, "Run not found");
  if (run.ended_at !== null) throw new HttpError(409, "Run already finished");

  const elapsed = Math.max(0.1, Date.now() / 1000 - run.started_at);
  const maxScore = Math.min(MAX_SCORE, Math.floor(elapsed * 850));
  const maxCoins = Math.floor(elapsed * COINS_PER_SEC_CAP) + COINS_RUN_SLACK;
  const valid = score <= maxScore + 5000 && coins <= maxCoins;

  // Close the run exactly once (prevents re-submitting a run to farm coins).
  const closed = await env.DB.prepare(
    "UPDATE game_runs SET ended_at=?1, score=?2, coins=?3, valid=?4 WHERE run_id=?5 AND telegram_id=?6 AND ended_at IS NULL"
  ).bind(Date.now() / 1000, score, valid ? coins : 0, valid ? 1 : 0, body.run_id, tg.id).run();
  if (closed.meta.changes !== 1) throw new HttpError(409, "Run already finished");

  if (valid) {
    if (score >= 1000) await qualifyReferral(env, tg.id);
    await env.DB.prepare(
      `UPDATE users SET best_score=MAX(best_score, ?1), coins=coins+?2, total_coins=total_coins+?2 WHERE telegram_id=?3`
    ).bind(score, coins, tg.id).run();
    // The million-point NFT is an eligibility record only. Minting is deliberately manual.
    if (score >= MAX_SCORE) {
      await env.DB.prepare(
        `INSERT OR IGNORE INTO nft_assets(telegram_id,source_type,source_id,title,status)
         VALUES(?1,'million_score',?2,'Million Score Champion','pending_review')`
      ).bind(tg.id, String(tg.id)).run();
    }
  }
  return { valid, score: valid ? score : 0, coins: valid ? coins : 0, elapsed: Math.round(elapsed * 100) / 100, user: await publicUser(env, tg.id) };
}
