import { HttpError } from "../lib/http.js";
import { allSettings, starsConfig } from "../lib/settings.js";
import { tgCall, notifyAdmin } from "../bot/telegram.js";

const ITEMS = new Set(["laser", "extra_life"]);
function parsePayload(x) {
  const m = String(x || "").match(/^star:(laser|extra_life):(\d+):(\d+):[\w-]+$/);
  return m ? { item: m[1], stars: Number(m[2]), uid: Number(m[3]) } : null;
}
export async function createInvoice(env, tg, body) {
  const c = starsConfig(await allSettings(env)), item = String(body.item || "");
  if (!c.enabled || !ITEMS.has(item) || !c.items[item]?.enabled) throw new HttpError(403, "Stars item unavailable");
  const owner = await env.DB.prepare(`SELECT ${item} AS owned FROM users WHERE telegram_id=?1`).bind(tg.id).first();
  if (owner?.owned) throw new HttpError(409, "Already owned");
  const stars = c.items[item].stars, title = item === "laser" ? "Laser" : "Extra Life";
  const r = await tgCall(env, "createInvoiceLink", { title, description: `UFO Runner — ${title}`, payload: `star:${item}:${stars}:${tg.id}:${crypto.randomUUID().slice(0, 8)}`, currency: "XTR", prices: [{ label: title, amount: stars }] });
  if (!r.ok) throw new HttpError(502, "Could not create Stars invoice");
  return { link: r.result };
}
export async function handlePreCheckout(env, q) {
  const c = starsConfig(await allSettings(env)), p = parsePayload(q.invoice_payload);
  const ok = !!(c.enabled && p && c.items[p.item]?.enabled && p.uid === q.from.id && q.currency === "XTR" && q.total_amount === p.stars);
  await tgCall(env, "answerPreCheckoutQuery", { pre_checkout_query_id: q.id, ok, ...(ok ? {} : { error_message: "This Stars item is no longer available." }) });
}
export async function handleSuccessfulPayment(env, msg) {
  const pay = msg.successful_payment, p = parsePayload(pay.invoice_payload);
  if (!p || pay.currency !== "XTR" || pay.total_amount !== p.stars || p.uid !== msg.from.id) {
    await notifyAdmin(env, `⚠️ Suspicious Stars payment ignored\nuser: ${msg.from?.id}\ncharge: ${pay.telegram_payment_charge_id}\namount: ${pay.total_amount} ${pay.currency}`);
    return;
  }
  try {
    await env.DB.prepare("INSERT INTO stars_purchases(charge_id,telegram_id,item,stars) VALUES(?1,?2,?3,?4)").bind(pay.telegram_payment_charge_id, p.uid, p.item, p.stars).run();
  } catch (e) { if (/UNIQUE|constraint/i.test(String(e?.message))) return; throw e; }
  if (p.item === "laser") await env.DB.prepare("UPDATE users SET laser=1 WHERE telegram_id=?1").bind(p.uid).run();
  if (p.item === "extra_life") await env.DB.prepare("UPDATE users SET extra_life=1 WHERE telegram_id=?1").bind(p.uid).run();
  await tgCall(env, "sendMessage", { chat_id: msg.chat.id, text: p.item === "laser" ? "🔴 Laser unlocked! Tap the right side of the screen to fire." : "❤️ Extra Life unlocked! It saves you from one crash per run." });
  await notifyAdmin(env, `⭐ New purchase: ${p.item} (${p.stars} ⭐)\nuser: ${p.uid}\ncharge: ${pay.telegram_payment_charge_id}`);
}

// ---- admin tools: list purchases and refund one (returns the ⭐ and takes the item back) ----
export async function recentPurchases(env) {
  const { results } = await env.DB.prepare("SELECT charge_id,telegram_id,item,stars,refunded,created_at FROM stars_purchases ORDER BY id DESC LIMIT 10").all();
  if (!results.length) return "—";
  return results.map((r) => `${r.refunded ? "↩️" : "✅"} ${r.item} ${r.stars}⭐ user ${r.telegram_id}\n${r.created_at}\n${r.charge_id}`).join("\n\n");
}
export async function refundStars(env, chargeId) {
  if (!chargeId) return "Example: /refund <charge_id>  (see /purchases)";
  const row = await env.DB.prepare("SELECT telegram_id,item,refunded FROM stars_purchases WHERE charge_id=?1").bind(chargeId).first();
  if (!row) return "Purchase not found";
  if (row.refunded) return "Already refunded";
  const r = await tgCall(env, "refundStarPayment", { user_id: row.telegram_id, telegram_payment_charge_id: chargeId });
  if (!r.ok) return `Telegram refused the refund: ${r.description || "unknown error"}`;
  await env.DB.prepare("UPDATE stars_purchases SET refunded=1 WHERE charge_id=?1").bind(chargeId).run();
  await env.DB.prepare(`UPDATE users SET ${row.item}=0 WHERE telegram_id=?1`).bind(row.telegram_id).run();   // item is only ever laser|extra_life
  return `✅ Refunded ${row.item} to user ${row.telegram_id}`;
}
