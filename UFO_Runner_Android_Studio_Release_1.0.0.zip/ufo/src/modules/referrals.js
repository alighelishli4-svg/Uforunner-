import { HttpError } from "../lib/http.js";

function makeCode() {
  const bytes = new Uint8Array(5);
  crypto.getRandomValues(bytes);
  return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("").toUpperCase();
}

export async function referralInfo(env, tg) {
  let row = await env.DB.prepare("SELECT code FROM referral_codes WHERE referrer_id=?1").bind(tg.id).first();
  if (!row) {
    for (let i = 0; i < 5 && !row; i++) {
      const code = makeCode();
      await env.DB.prepare("INSERT OR IGNORE INTO referral_codes(code,referrer_id) VALUES(?1,?2)").bind(code, tg.id).run();
      row = await env.DB.prepare("SELECT code FROM referral_codes WHERE referrer_id=?1").bind(tg.id).first();
    }
  }
  if (!row) throw new HttpError(503, "Could not create referral code");
  const count = await env.DB.prepare("SELECT COUNT(*) AS n FROM referral_edges WHERE referrer_id=?1 AND qualified_at IS NOT NULL").bind(tg.id).first();
  const claims = await env.DB.prepare("SELECT ufo_id FROM referral_reward_claims WHERE referrer_id=?1").bind(tg.id).all();
  const claimed = new Set(claims.results.map((x) => x.ufo_id));
  const username = env.BOT_USERNAME || "Ufo2026_game_bot";
  return {
    code: row.code,
    invite_url: `https://t.me/${username}?start=ref_${row.code}`,
    qualified_friends: count?.n || 0,
    comet_unlocked: claimed.has("comet"),
    nova_unlocked: claimed.has("nova"),
    next_reward: (count?.n || 0) < 5 ? "comet" : (count?.n || 0) < 10 ? "nova" : null,
  };
}

export async function recordReferral(env, referredId, code) {
  if (!/^[A-F0-9]{10}$/.test(String(code || "").toUpperCase())) return false;
  const ref = await env.DB.prepare("SELECT referrer_id FROM referral_codes WHERE code=?1").bind(String(code).toUpperCase()).first();
  if (!ref || Number(ref.referrer_id) === Number(referredId)) return false;
  const result = await env.DB.prepare("INSERT OR IGNORE INTO referral_edges(referred_id,referrer_id,code) VALUES(?1,?2,?3)")
    .bind(referredId, ref.referrer_id, String(code).toUpperCase()).run();
  return result.meta.changes === 1;
}

export async function qualifyReferral(env, referredId) {
  const edge = await env.DB.prepare("SELECT referrer_id FROM referral_edges WHERE referred_id=?1 AND qualified_at IS NULL").bind(referredId).first();
  if (!edge) return;
  const changed = await env.DB.prepare("UPDATE referral_edges SET qualified_at=CURRENT_TIMESTAMP WHERE referred_id=?1 AND qualified_at IS NULL").bind(referredId).run();
  if (changed.meta.changes !== 1) return;
  const referrerId = edge.referrer_id;
  const count = await env.DB.prepare("SELECT COUNT(*) AS n FROM referral_edges WHERE referrer_id=?1 AND qualified_at IS NOT NULL").bind(referrerId).first();
  const rewards = [];
  if (count.n >= 5) rewards.push("comet");
  if (count.n >= 10) rewards.push("nova");
  for (const ufoId of rewards) {
    const existing = await env.DB.prepare("SELECT 1 AS yes FROM referral_reward_claims WHERE referrer_id=?1 AND ufo_id=?2").bind(referrerId, ufoId).first();
    if (existing) continue;
    const stock = await env.DB.prepare(
      `UPDATE ufo_inventory SET remaining=remaining-1,sold_count=sold_count+1
       WHERE ufo_id=?1 AND remaining>0 AND (SELECT COUNT(*) FROM referral_reward_claims WHERE ufo_id=?1)<50
       RETURNING sold_count`
    ).bind(ufoId).first();
    if (!stock) continue;
    await env.DB.batch([
      env.DB.prepare("INSERT OR IGNORE INTO referral_reward_claims(referrer_id,ufo_id,serial_no) VALUES(?1,?2,?3)").bind(referrerId, ufoId, stock.sold_count),
      env.DB.prepare("INSERT OR IGNORE INTO user_ufos(telegram_id,ufo_id) VALUES(?1,?2)").bind(referrerId, ufoId),
    ]);
  }
}
