import { MAX_LEVEL, upgradeCost, UPGRADE_COLUMN } from "../config/constants.js";
import { HttpError } from "../lib/http.js";
import { getUser, publicUser } from "../lib/db.js";

// Coin upgrades are deliberately limited to speed/maneuver. Premium digital
// features (Laser/Extra Life) are handled by the separate Telegram Stars module.
export async function upgrade(env, tg, body) {
  const user = await getUser(env, tg.id);
  if (!user) throw new HttpError(404, "User not found");
  const col = UPGRADE_COLUMN[body.key];
  if (!col) throw new HttpError(400, "Unknown upgrade");
  const level = user[col];
  if (level >= MAX_LEVEL) throw new HttpError(400, "Max level");
  const cost = upgradeCost(level);
  const res = await env.DB.prepare(`UPDATE users SET coins=coins-?1, ${col}=${col}+1 WHERE telegram_id=?2 AND coins>=?1 AND ${col}=?3`)
    .bind(cost, tg.id, level).run();
  if (res.meta.changes !== 1) throw new HttpError(400, "Not enough coins");
  return { ok: true, user: await publicUser(env, tg.id) };
}
