import { HttpError } from "../lib/http.js";
import { allSettings, funConfig } from "../lib/settings.js";
import { publicUser } from "../lib/db.js";

export async function wallet(env, tg) {
  return { fun: funConfig(await allSettings(env)), user: await publicUser(env, tg.id) };
}
export async function connectWallet(_env, _tg, _body) {
  throw new HttpError(501, "TON Connect proof verification is not enabled yet");
}
export async function verifyDeposit(_env, _tg, _body) {
  throw new HttpError(501, "FUN settlement is not enabled until the TON token is launched");
}
