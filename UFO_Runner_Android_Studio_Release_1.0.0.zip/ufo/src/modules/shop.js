import { HttpError } from "../lib/http.js";
import { ownedUfos, publicUser } from "../lib/db.js";
import { allSettings, ufoCatalog, funConfig } from "../lib/settings.js";

export async function buyUfo(env, tg, body) {
  const fun = funConfig(await allSettings(env));
  // Fail closed: a database balance is not proof of an on-chain Jetton payment.
  // Real purchases stay locked until a TON transaction verifier is configured.
  if (!fun.salesEnabled || !fun.onchainPaymentsReady) {
    throw new HttpError(503, "FUN UFO purchases are locked until on-chain payment verification is configured");
  }
  const ufo = ufoCatalog(await allSettings(env)).find((u) => u.id === body.ufo_id);
  if (!ufo || ufo.price <= 0) throw new HttpError(400, "Unknown UFO");
  if ((await ownedUfos(env, tg.id)).includes(ufo.id)) throw new HttpError(409, "Already owned");
  const user = await env.DB.prepare("SELECT fun_balance FROM users WHERE telegram_id=?1").bind(tg.id).first();
  if (!user || user.fun_balance < ufo.price) throw new HttpError(400, "Not enough FUN");

  // Reserve one serial from this model's fixed supply. If payment fails, release it.
  const stock = await env.DB.prepare(
    "UPDATE ufo_inventory SET remaining=remaining-1, sold_count=sold_count+1 WHERE ufo_id=?1 AND remaining>0 RETURNING sold_count"
  ).bind(ufo.id).first();
  if (!stock) throw new HttpError(409, "This UFO is sold out");
  const paid = await env.DB.prepare("UPDATE users SET fun_balance=fun_balance-?1 WHERE telegram_id=?2 AND fun_balance>=?1")
    .bind(ufo.price, tg.id).run();
  if (paid.meta.changes !== 1) {
    await env.DB.prepare("UPDATE ufo_inventory SET remaining=remaining+1, sold_count=sold_count-1 WHERE ufo_id=?1").bind(ufo.id).run();
    throw new HttpError(400, "Not enough FUN");
  }
  try {
    await env.DB.batch([
      env.DB.prepare(`INSERT INTO ufo_purchases(telegram_id,ufo_id,serial_no,price_fun,source)
        VALUES(?1,?2,?3,?4,'primary')`).bind(tg.id, ufo.id, stock.sold_count, ufo.price),
      env.DB.prepare("INSERT INTO user_ufos(telegram_id,ufo_id) VALUES(?1,?2)").bind(tg.id, ufo.id),
      env.DB.prepare(`INSERT INTO nft_assets(telegram_id,source_type,source_id,title,status)
        SELECT ?1,'ufo_purchase',CAST(id AS TEXT),?3,'eligible' FROM ufo_purchases
        WHERE telegram_id=?1 AND ufo_id=?2 ORDER BY id DESC LIMIT 1`).bind(tg.id, ufo.id, `${ufo.name.en} #${stock.sold_count}`),
    ]);
  } catch (e) {
    await env.DB.prepare("UPDATE users SET fun_balance=fun_balance+?1 WHERE telegram_id=?2").bind(ufo.price, tg.id).run();
    await env.DB.prepare("UPDATE ufo_inventory SET remaining=remaining+1, sold_count=sold_count-1 WHERE ufo_id=?1").bind(ufo.id).run();
    throw e;
  }
  return { ok: true, user: await publicUser(env, tg.id) };
}

export async function selectUfo(env, tg, body) {
  if (!(await ownedUfos(env, tg.id)).includes(body.ufo_id)) throw new HttpError(400, "UFO not owned");
  await env.DB.prepare("UPDATE users SET selected_ufo=?1 WHERE telegram_id=?2").bind(body.ufo_id, tg.id).run();
  return { ok: true, user: await publicUser(env, tg.id) };
}
