export const MAX_SCORE = 1_000_000;
export const MAX_LEVEL = 10;
export const COINS_PER_SEC_CAP = 4;
export const COINS_RUN_SLACK = 4;
export const AUTH_MAX_AGE = 86400;
export const upgradeCost = (level) => 20 * level;
export const UPGRADE_COLUMN = { speed: "speed_level", maneuver: "maneuver_level" };
export const FLAGS = {
  fun_enabled: "💎 FUN / TON Wallet",
  stars_shop_enabled: "⭐ فروش قابلیت‌های ویژه",
  stars_laser_enabled: "🔴 فروش لیزر (⭐)",
  stars_extra_life_enabled: "❤️ فروش جان اضافه (⭐)",
};
