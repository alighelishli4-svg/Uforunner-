// FUN-priced UFO catalogue. Supply caps are provisional launch settings and belong to each model.
// Rarity never grants an automatic competitive advantage: stats remain separately balanceable.
export const UFOS = [
  { id: "scout",    speed: 0,    maneuver: 0,   price: 0,    supply: null, name: { en: "Scout",    fa: "پیشاهنگ" } },
  { id: "comet",    speed: 0.08, maneuver: 70,  price: 100,  supply: 200, name: { en: "Comet",    fa: "ستاره‌دنباله‌دار" } },
  { id: "nova",     speed: 0.16, maneuver: 140, price: 250,  supply: 150, name: { en: "Nova",     fa: "نوا" } },
  { id: "phantom",  speed: 0.26, maneuver: 215, price: 500,  supply: 1250, name: { en: "Phantom",  fa: "شبح" } },
  { id: "vortex",   speed: 0.38, maneuver: 295, price: 900,  supply: 625,  name: { en: "Vortex",   fa: "گردباد" } },
  { id: "eclipse",  speed: 0.52, maneuver: 380, price: 1500, supply: 300,  name: { en: "Eclipse",  fa: "کسوف" } },
  { id: "aurora",   speed: 0.70, maneuver: 480, price: 2500, supply: 100,  name: { en: "Aurora",   fa: "شفق" } },
];
export const STARTER_UFO = "scout";
export function catalogWith(priceOverrides = {}) {
  return UFOS.map((u) => ({ ...u, price: u.id === STARTER_UFO ? 0 : (Number.isInteger(priceOverrides[u.id]) && priceOverrides[u.id] > 0 ? priceOverrides[u.id] : u.price) }));
}
