# تغییرات UFO Runner

## نسخه ۵ — FUN/TON، عرضه محدود UFO و آماده‌سازی NFT
- اصلاح نام توکن به **FUN** در تنظیمات، API، پنل ادمین و رابط کاربری. ستون قدیمی FAN فقط برای انتقال امن داده‌های دیتابیس باقی می‌ماند.
- حذف کامل Airdrop از تنظیمات، منو و پرچم‌های ادمین.
- اضافه‌شدن عرضه ثابت و مستقل برای هر UFO، شمارنده موجودی، شماره سریال و وضعیت Sold Out.
- خرید هر UFO مالکیت قابل استفاده در بازی ایجاد می‌کند؛ انتخاب UFO خریداری‌شده به سیستم فعلی بازی متصل است.
- ثبت تاریخچه‌ی خرید و رکورد واجدشرایط‌بودن NFT برای همه خریدهای جدید؛ مالکیت‌های قدیمی نیز در migration حفظ می‌شوند.
- افزودن پاداش ویژه Million Score Champion برای امتیاز معتبر ۱٬۰۰۰٬۰۰۰. این پاداش از فروشگاه و سهمیه UFOها جداست.
- هیچ مینتی خودکار انجام نمی‌شود. مینت واقعی پس از دستور صریح و تکمیل قرارداد TEP-62/متادیتای TEP-64 پیاده‌سازی خواهد شد.
- migration دیتابیس: `migrations/004_fun_scarcity_nft.sql`.

## ویژگی‌های حفظ‌شده از نسخه ۵ قبلی
- لیزر دستی با کول‌داون و جان اضافه‌ی یک‌بارمصرف با Telegram Stars.
- ارتقای سرعت و مانور با سکه.
- ساختار ماژولار Cloudflare Worker، بازی، ربات و پنل ادمین.

## 2026-10-30 — FUN sales kept under owner control
- Added a separate `fun_sales_enabled` switch; FUN/TON configuration and in-game UFO sales are no longer the same toggle.
- UFO purchases are rejected by the server with HTTP 503 until the owner explicitly enables sales.
- The in-game shop displays a disabled/coming-soon state and no longer displays a FUN balance in the main HUD.
- Owner-only commands: `/fun_sales_on` and `/fun_sales_off`. Enabling requires `/fun_on` and a saved launched token address first.
- FUN remains a database/test placeholder; no on-chain payment, DEX trading, or NFT minting is claimed as implemented.

## Release Candidate 1.0.0 — 2026-11-04
- Removed F-35/F-22 aircraft and all non-F-14 fighter designations; remaining aircraft use generic internal identifiers and only F-14 is visibly named and hostile.
- Added Android standalone boot/auth support so Android sessions can load `/api/me` and start runs without Telegram `initData`.
- Added referral invite links, new-user attribution, server-verified 1,000-score qualification, and capped Comet/Nova referral rewards.
- Updated Comet/Nova total supply to 200/150 with up to 50 referral rewards per model.
- Added FUN/TON wallet entry point and preserved external token acquisition settings; real FUN UFO purchases remain fail-closed until on-chain verification is deployed.
- Added GitHub Actions workflow for Android APK builds.
