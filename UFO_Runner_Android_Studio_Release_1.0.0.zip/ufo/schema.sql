-- Fresh install. (Existing installs: run migrations/002_shop_fun.sql instead.)
CREATE TABLE IF NOT EXISTS users (
  telegram_id INTEGER PRIMARY KEY,
  username TEXT,
  first_name TEXT,
  language TEXT DEFAULT 'en',
  best_score INTEGER DEFAULT 0,
  coins INTEGER DEFAULT 0,
  total_coins INTEGER DEFAULT 0,
  fan_balance INTEGER DEFAULT 0, -- legacy column retained for safe upgrade
  fun_balance INTEGER DEFAULT 0,
  ton_address TEXT DEFAULT '',
  selected_ufo TEXT DEFAULT 'scout',
  speed_level INTEGER DEFAULT 1,
  maneuver_level INTEGER DEFAULT 1,
  extra_life INTEGER DEFAULT 0,
  laser INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS game_runs (
  run_id TEXT PRIMARY KEY,
  telegram_id INTEGER NOT NULL,
  started_at REAL NOT NULL,
  ended_at REAL,
  score INTEGER DEFAULT 0,
  coins INTEGER DEFAULT 0,
  valid INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stars_purchases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  charge_id TEXT NOT NULL UNIQUE,
  telegram_id INTEGER NOT NULL,
  item TEXT NOT NULL,
  stars INTEGER NOT NULL,
  refunded INTEGER NOT NULL DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_ufos (
  telegram_id INTEGER NOT NULL,
  ufo_id TEXT NOT NULL,
  PRIMARY KEY (telegram_id, ufo_id)
);

INSERT OR IGNORE INTO settings(key, value) VALUES
  ('fun_enabled','0'),
  ('stars_shop_enabled','0'),
  ('stars_laser_enabled','0'),
  ('stars_extra_life_enabled','0'),
  ('stars_laser','50'),
  ('stars_extra_life','75'),
  ('fun_decimals','9');

CREATE TABLE IF NOT EXISTS ufo_inventory (
  ufo_id TEXT PRIMARY KEY, supply_total INTEGER NOT NULL, remaining INTEGER NOT NULL, sold_count INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO ufo_inventory(ufo_id,supply_total,remaining,sold_count) VALUES
 ('comet',5000,5000,0),('nova',2500,2500,0),('phantom',1250,1250,0),('vortex',625,625,0),('eclipse',300,300,0),('aurora',100,100,0);
CREATE TABLE IF NOT EXISTS ufo_purchases (
 id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL, ufo_id TEXT NOT NULL, serial_no INTEGER NOT NULL,
 price_fun INTEGER NOT NULL, source TEXT NOT NULL DEFAULT 'primary', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(ufo_id,serial_no)
);
CREATE TABLE IF NOT EXISTS nft_assets (
 id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL, source_type TEXT NOT NULL, source_id TEXT NOT NULL,
 title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'eligible', collection_address TEXT DEFAULT '', item_address TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, minted_at TEXT, UNIQUE(source_type,source_id)
);
