// Sky scenery: gradient, sun/moon, stars, 3-layer parallax clouds, random day <-> night switches.
import { rand, mix, rgba } from "./utils.js";

const DAY = { top: "#123d82", mid: "#3f86d0", bot: "#a9d6f5", cloud: "#ffffff" };
const NIGHT = { top: "#040a1c", mid: "#0b1f4a", bot: "#27457e", cloud: "#8da2c9" };

let clouds = [], stars = [], night = 0, target = 0, nextSwitch = rand(1200, 3200), W = 360, H = 600;
export const nightFactor = () => night;

function makeCloud(layer, x) {
  const scale = [0.5, 0.85, 1.4][layer], count = 4 + Math.floor(Math.random() * 3), puffs = [];
  for (let i = 0; i < count; i++)
    puffs.push({ dx: (i - count / 2) * 22 * scale + Math.random() * 10, dy: (Math.random() - .5) * 14 * scale, r: (20 + Math.random() * 16) * scale });
  return { layer, x, y: Math.random() * H * (layer === 2 ? 1 : 0.85), puffs, speed: [0.08, 0.22, 0.55][layer], alpha: [.35, .5, .72][layer] };
}
export function initSky(w, h) {
  W = w || 360; H = h || 600; clouds = [];
  [7, 6, 4].forEach((n, layer) => { for (let i = 0; i < n; i++) clouds.push(makeCloud(layer, Math.random() * W)); });
  stars = Array.from({ length: 70 }, () => ({ x: Math.random(), y: Math.random() * 0.8, r: Math.random() * 1.4 + .4, p: Math.random() * 6 }));
}
// Call when a new run (or the idle menu) starts counting score from zero.
export function resetCycle() { nextSwitch = rand(1200, 3200); }

// score drives the day/night schedule: a switch happens every ~1500-3800 points (random).
export function stepSky(dt, worldSpeed, score) {
  if (score >= nextSwitch) { target = target ? 0 : 1; nextSwitch = score + rand(1500, 3800); }
  night += (target - night) * Math.min(1, dt * 0.9);
  for (const c of clouds) {
    c.x -= worldSpeed * c.speed * dt;
    if (c.x < -170) Object.assign(c, makeCloud(c.layer, W + 120 + Math.random() * 80));
  }
}

export function drawSky(ctx, t) {
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, mix(DAY.top, NIGHT.top, night)); g.addColorStop(.55, mix(DAY.mid, NIGHT.mid, night)); g.addColorStop(1, mix(DAY.bot, NIGHT.bot, night));
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

  const cx = W * .8, cy = H * .18;
  if (night < 1) {                                   // sun glow
    const sg = ctx.createRadialGradient(cx, cy, 5, cx, cy, H * .45);
    sg.addColorStop(0, rgba("#fff4c8", .55 * (1 - night))); sg.addColorStop(1, rgba("#fff4c8", 0));
    ctx.fillStyle = sg; ctx.fillRect(0, 0, W, H);
  }
  if (night > 0.02) {                                // stars + moon
    for (const s of stars) {
      ctx.globalAlpha = night * (0.45 + 0.55 * Math.abs(Math.sin(t * 1.5 + s.p)));
      ctx.fillStyle = "#fff"; ctx.fillRect(s.x * W, s.y * H, s.r, s.r);
    }
    ctx.globalAlpha = night;
    const mg = ctx.createRadialGradient(cx, cy, 6, cx, cy, 60);
    mg.addColorStop(0, "rgba(190,210,255,.5)"); mg.addColorStop(1, "rgba(190,210,255,0)");
    ctx.fillStyle = mg; ctx.fillRect(cx - 70, cy - 70, 140, 140);
    ctx.fillStyle = "#eef3ff"; ctx.beginPath(); ctx.arc(cx, cy, 17, 0, 7); ctx.fill();
    ctx.fillStyle = "rgba(150,165,200,.55)";
    [[-5, -3, 4], [5, 4, 3], [4, -7, 2.2]].forEach(([dx, dy, r]) => { ctx.beginPath(); ctx.arc(cx + dx, cy + dy, r, 0, 7); ctx.fill(); });
    ctx.globalAlpha = 1;
  }
  ctx.fillStyle = mix(DAY.cloud, NIGHT.cloud, night);
  for (const c of clouds) {
    ctx.globalAlpha = c.alpha; ctx.beginPath();
    for (const p of c.puffs) { ctx.moveTo(c.x + p.dx + p.r, c.y + p.dy); ctx.arc(c.x + p.dx, c.y + p.dy, p.r, 0, Math.PI * 2); }
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}
