import { api } from "./api.js?v=12";
const button = document.getElementById("linkTelegram");
if (button && window.AndroidUFO?.isAndroidApp?.()) {
  button.classList.remove("hidden");
  button.textContent = (document.documentElement.lang || "").startsWith("fa") ? "اتصال به حساب تلگرام" : "LINK TELEGRAM ACCOUNT";
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      const result = await api("/api/android/link-code");
      const message = `برای اتصال حساب اندروید به تلگرام، ربات @Ufo2026_game_bot را باز کن و این دستور را بفرست:

/link ${result.code}

این کد تا ۱۰ دقیقه معتبر است.`;
      alert(message);
    } catch (e) { alert("خطا در ساخت کد اتصال: " + e.message); }
    finally { button.disabled = false; }
  });
}
