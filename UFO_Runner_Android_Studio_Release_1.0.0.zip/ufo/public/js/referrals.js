import { api } from "./api.js?v=12";
const $ = (id) => document.getElementById(id);
const btn = $("referralBtn"), panel = $("referralPanel"), home = $("home"), shop = $("shop");
let inviteUrl = "";
const fa = () => (document.documentElement.lang || "").toLowerCase().startsWith("fa");
function show() { home.classList.add("hidden"); shop.classList.add("hidden"); panel.classList.remove("hidden"); }
function back() { panel.classList.add("hidden"); home.classList.remove("hidden"); }
btn?.addEventListener("click", async () => {
  show();
  $("referralTitle").textContent = fa() ? "دعوت دوستان" : "INVITE FRIENDS";
  $("referralProgress").textContent = fa() ? "در حال دریافت کد دعوت..." : "Loading your invite link...";
  try {
    const d = await api("/api/referral"); inviteUrl = d.invite_url;
    $("referralLink").value = inviteUrl;
    $("referralCount").textContent = fa() ? `دوستان واجد شرایط: ${d.qualified_friends}` : `Qualified friends: ${d.qualified_friends}`;
    const next = d.next_reward === "comet" ? (fa() ? "۵ دوست واجد شرایط: سفینه Comet" : "5 qualified friends: Comet UFO")
      : d.next_reward === "nova" ? (fa() ? "۱۰ دوست واجد شرایط: سفینه Nova" : "10 qualified friends: Nova UFO")
      : (fa() ? "پاداش‌های دعوت فعلی تکمیل شده‌اند." : "Current referral rewards completed.");
    $("referralProgress").textContent = next;
  } catch (e) { $("referralProgress").textContent = fa() ? "خطا در دریافت لینک دعوت. اتصال اینترنت را بررسی کن." : "Could not load invite link. Check your connection."; }
});
$("referralBack")?.addEventListener("click", back);
$("referralCopy")?.addEventListener("click", async () => {
  if (!inviteUrl) return;
  try { await navigator.clipboard.writeText(inviteUrl); $("referralCopy").textContent = fa() ? "کپی شد ✓" : "COPIED ✓"; }
  catch { $("referralLink").select(); document.execCommand("copy"); }
});
$("referralShare")?.addEventListener("click", async () => {
  if (!inviteUrl) return;
  const text = fa() ? "بیا UFO Runner رو بازی کن!" : "Join me in UFO Runner!";
  if (navigator.share) { try { await navigator.share({ title: "UFO Runner", text, url: inviteUrl }); } catch {} }
  else { try { await navigator.clipboard.writeText(`${text} ${inviteUrl}`); } catch {} }
});
