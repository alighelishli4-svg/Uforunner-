export const tg = window.Telegram?.WebApp;
export const initData = tg?.initData || "";

function androidToken() {
  try { return window.AndroidUFO?.getToken?.() || ""; } catch { return ""; }
}

export async function api(path, body = {}) {
  const token = androidToken();
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(path, {
    method: "POST", headers,
    body: JSON.stringify({ ...(initData ? { init_data: initData } : {}), ...body }),
  });
  if (!res.ok) {
    let msg = "error"; try { msg = (await res.json()).error; } catch {}
    const e = new Error(msg); e.status = res.status; throw e;
  }
  return res.json();
}
