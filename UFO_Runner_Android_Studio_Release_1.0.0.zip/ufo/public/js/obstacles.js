// Obstacle types. Add an entry to OBSTACLES to add a new type — spawning, hit-testing, laser and drawing are data-driven.
// `destructible:false` = laser cannot destroy it (the player is told about this in-game and on the laser card).
import { rand, rgba } from "./utils.js";

const poly = (ctx, pts) => { ctx.beginPath(); pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.closePath(); };

export const OBSTACLES = {
  asteroid: { w: 46, h: 42, minScore: 0, weight: 5, destructible: true, spin: 0.8, scale: [0.8, 1.4],
    draw(ctx, o) {
      const n = o.shape.length, pts = o.shape.map((r, i) => [Math.cos(i / n * 6.283) * r * 22, Math.sin(i / n * 6.283) * r * 20]);
      const g = ctx.createRadialGradient(-6, -6, 3, 0, 0, 26); g.addColorStop(0, "#a69883"); g.addColorStop(1, "#4b4136");
      poly(ctx, pts); ctx.fillStyle = g; ctx.fill(); ctx.lineWidth = 1.5; ctx.strokeStyle = "#2d261f"; ctx.stroke();
      ctx.fillStyle = "rgba(40,32,24,.45)";
      [[-7, -4, 5], [8, 5, 4], [2, -10, 3]].forEach(([x, y, r]) => { ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); });
    } },
  missile: { w: 58, h: 16, minScore: 1500, weight: 3, destructible: true, speedMul: 1.7, scale: [1, 1],
    draw(ctx, o, t) {
      const f = 14 + Math.random() * 8, g = ctx.createLinearGradient(20, 0, 20 + f + 10, 0);
      g.addColorStop(0, "#fff2a8"); g.addColorStop(.5, "#ff7a1c"); g.addColorStop(1, "rgba(255,80,20,0)");
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(18, -4); ctx.lineTo(30 + f, 0); ctx.lineTo(18, 4); ctx.fill();
      const b = ctx.createLinearGradient(0, -5, 0, 5); b.addColorStop(0, "#f1f4f9"); b.addColorStop(1, "#8a95a8");
      ctx.fillStyle = b; ctx.beginPath(); ctx.roundRect(-18, -5, 38, 10, 4); ctx.fill();
      ctx.fillStyle = "#d83a3a"; ctx.beginPath(); ctx.moveTo(-18, -5); ctx.lineTo(-30, 0); ctx.lineTo(-18, 5); ctx.fill();       // nose
      ctx.fillStyle = "#5b6577"; poly(ctx, [[12, -5], [22, -11], [22, -5]]); ctx.fill(); poly(ctx, [[12, 5], [22, 11], [22, 5]]); ctx.fill();
      ctx.fillStyle = "#d83a3a"; ctx.fillRect(-4, -5, 4, 10);
    } },
  drone: { w: 40, h: 26, minScore: 3000, weight: 3, destructible: true, bob: 26, bobSpeed: 2.4, scale: [1, 1],
    draw(ctx, o, t) {
      ctx.strokeStyle = "#2c3340"; ctx.lineWidth = 2;
      [[-15, -9], [15, -9], [-15, 9], [15, 9]].forEach(([x, y]) => {
        ctx.beginPath(); ctx.moveTo(x * .4, y * .4); ctx.lineTo(x, y); ctx.stroke();
        ctx.fillStyle = "rgba(190,215,255,.55)"; ctx.beginPath(); ctx.ellipse(x, y, 9 + Math.sin(t * 60 + x) * 1.5, 2.4, 0, 0, 7); ctx.fill();
      });
      const g = ctx.createLinearGradient(0, -7, 0, 7); g.addColorStop(0, "#8793a8"); g.addColorStop(1, "#334057");
      ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(-10, -6, 20, 12, 5); ctx.fill(); ctx.strokeStyle = "#c3cde0"; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = Math.sin(t * 8) > 0 ? "#ff3b3b" : "#7a1c1c"; ctx.beginPath(); ctx.arc(-3, 0, 2.6, 0, 7); ctx.fill();
      ctx.fillStyle = "#9fe3ff"; ctx.fillRect(4, -2, 4, 4);
    } },
  satellite: { w: 60, h: 44, minScore: 5000, weight: 2, destructible: true, spin: 0.35, tilt: true, scale: [0.9, 1.15],
    draw(ctx) {
      const panel = (x) => {
        ctx.fillStyle = "#1c3f86"; ctx.fillRect(x, -9, 22, 18); ctx.strokeStyle = "#7fb0ff"; ctx.lineWidth = .8;
        for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(x + i * 5.5, -9); ctx.lineTo(x + i * 5.5, 9); ctx.stroke(); }
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + 22, 0); ctx.stroke(); ctx.strokeRect(x, -9, 22, 18);
      };
      panel(-30); panel(8);
      const g = ctx.createLinearGradient(0, -9, 0, 9); g.addColorStop(0, "#f4d986"); g.addColorStop(1, "#a9822a");
      ctx.fillStyle = g; ctx.fillRect(-8, -9, 16, 18); ctx.strokeStyle = "#5c4513"; ctx.lineWidth = 1; ctx.strokeRect(-8, -9, 16, 18);
      ctx.fillStyle = "#dfe6f2"; ctx.beginPath(); ctx.arc(0, -14, 6, Math.PI, 0); ctx.fill();
      ctx.strokeStyle = "#dfe6f2"; ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(0, -14); ctx.stroke();
    } },
  storm: { w: 84, h: 52, minScore: 7000, weight: 2, destructible: true, scale: [0.9, 1.2],
    draw(ctx, o, t) {
      ctx.fillStyle = "#4a5775";
      [[-24, 4, 16], [-6, -4, 20], [14, 2, 18], [28, 8, 12], [-2, 10, 18]].forEach(([x, y, r]) => { ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); });
      ctx.fillStyle = "#6c7b9c";
      [[-18, -2, 11], [4, -8, 12], [20, 0, 10]].forEach(([x, y, r]) => { ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); });
      if (Math.sin(t * 5 + o.phase) > 0.75) {                                   // lightning flash
        ctx.fillStyle = "rgba(255,245,160,.95)"; poly(ctx, [[4, 8], [-5, 24], [1, 24], [-4, 38], [10, 20], [3, 20], [8, 8]]); ctx.fill();
        ctx.fillStyle = rgba("#ffffcc", .25); ctx.beginPath(); ctx.arc(0, 4, 34, 0, 7); ctx.fill();
      }
    } },
  mine: { w: 44, h: 44, minScore: 9000, weight: 2, destructible: false, spin: 0.5, scale: [1, 1],
    draw(ctx, o, t) {
      const pulse = 0.5 + 0.5 * Math.sin(t * 5 + o.phase);
      const aura = ctx.createRadialGradient(0, 0, 14, 0, 0, 32); aura.addColorStop(0, rgba("#ff3b2f", .35 + .25 * pulse)); aura.addColorStop(1, rgba("#ff3b2f", 0));
      ctx.fillStyle = aura; ctx.beginPath(); ctx.arc(0, 0, 32, 0, 7); ctx.fill();
      ctx.fillStyle = "#3a404d";
      for (let i = 0; i < 10; i++) { const a = i / 10 * 6.283; ctx.save(); ctx.rotate(a); poly(ctx, [[17, -3.5], [27, 0], [17, 3.5]]); ctx.fill(); ctx.restore(); }
      const g = ctx.createRadialGradient(-6, -6, 3, 0, 0, 19); g.addColorStop(0, "#a3acbb"); g.addColorStop(.6, "#4d5566"); g.addColorStop(1, "#1d222c");
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, 18, 0, 7); ctx.fill();
      ctx.strokeStyle = "#ffb02e"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, 18, 0, 7); ctx.stroke();                     // hazard ring
      ctx.strokeStyle = "rgba(0,0,0,.45)"; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(0, 0, 11, 0, 7); ctx.moveTo(-18, 0); ctx.lineTo(18, 0); ctx.stroke();
      ctx.fillStyle = rgba("#ff5a3c", .7 + .3 * pulse); ctx.beginPath(); ctx.arc(0, 0, 5 + 1.5 * pulse, 0, 7); ctx.fill();            // core
    } },
};
export const MINE = "mine";

export function spawnObstacle(score, canvasW, canvasH) {
  const pool = Object.entries(OBSTACLES).filter(([, d]) => score >= d.minScore);
  let r = Math.random() * pool.reduce((s, [, d]) => s + d.weight, 0), type = pool[0][0];
  for (const [k, d] of pool) { if ((r -= d.weight) <= 0) { type = k; break; } }
  const d = OBSTACLES[type], sc = rand(d.scale[0], d.scale[1]), y = 55 + Math.random() * (canvasH - 110);
  return { type, x: canvasW + 60, y, baseY: y, w: d.w * sc, h: d.h * sc, sc, phase: Math.random() * 6, rot: Math.random() * 6,
    shape: Array.from({ length: 9 }, () => rand(0.8, 1.15)) };
}
export function updateObstacle(o, dt, worldSpeed) {
  const d = OBSTACLES[o.type];
  o.x -= worldSpeed * (d.speedMul || 1) * dt;
  o.phase += dt * (d.bobSpeed || 1.5);
  if (d.bob) o.y = Math.max(40, o.baseY + Math.sin(o.phase) * d.bob);
  if (d.spin) o.rot += dt * d.spin;
}
export function drawObstacle(ctx, o, t) {
  const d = OBSTACLES[o.type];
  ctx.save(); ctx.translate(o.x, o.y); ctx.scale(o.sc, o.sc);
  if (d.tilt) ctx.rotate(Math.sin(o.rot) * 0.35); else if (o.type === "asteroid" || o.type === "mine") ctx.rotate(o.rot);
  d.draw(ctx, o, t); ctx.restore();
}
