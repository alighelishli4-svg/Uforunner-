// UFO designs. drawUfo(ctx, id, t, night) draws around (0,0), facing right, roughly 56x30 px.
// To add a UFO: add a draw function here + an entry in src/config/catalog.js (server).
import { rgba } from "./utils.js";

const TAU = Math.PI * 2;
const grad = (ctx, y0, y1, stops) => { const g = ctx.createLinearGradient(0, y0, 0, y1); stops.forEach(([o, c]) => g.addColorStop(o, c)); return g; };
const ell = (ctx, x, y, rx, ry, fill) => { ctx.fillStyle = fill; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, TAU); ctx.fill(); };

function glow(ctx, color, r, a) {                       // soft light under / around the craft
  const g = ctx.createRadialGradient(0, 4, 2, 0, 4, r);
  g.addColorStop(0, rgba(color, a)); g.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 4, r, 0, TAU); ctx.fill();
}
function dome(ctx, cx, base, rx, ry, c1, c2) {           // glass cockpit with highlight
  ctx.fillStyle = grad(ctx, base - ry, base, [[0, c1], [1, c2]]);
  ctx.beginPath(); ctx.ellipse(cx, base, rx, ry, 0, Math.PI, TAU); ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.55)"; ctx.lineWidth = 1; ctx.stroke();
  ctx.fillStyle = "rgba(255,255,255,.55)"; ctx.beginPath(); ctx.ellipse(cx - rx * .35, base - ry * .6, rx * .25, ry * .22, -.5, 0, TAU); ctx.fill();
}
function lights(ctx, xs, y, t, color, r = 1.7) {         // chasing rim lights
  xs.forEach((x, i) => { ctx.globalAlpha = 0.45 + 0.55 * Math.max(0, Math.sin(t * 6 - i * 1.1)); ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); });
  ctx.globalAlpha = 1;
}

const UFO = {
  scout(ctx, t, n) {                                     // classic silver saucer
    glow(ctx, "#7fd0ff", 36, .22 + .2 * n);
    ctx.strokeStyle = "#667286"; ctx.lineWidth = 2;
    [-13, 13].forEach((x) => { ctx.beginPath(); ctx.moveTo(x * .75, 8); ctx.lineTo(x, 14); ctx.stroke(); ell(ctx, x, 14.5, 3.2, 1.2, "#667286"); });
    ctx.fillStyle = grad(ctx, -7, 11, [[0, "#f6f9fd"], [.5, "#aab5c6"], [1, "#586377"]]);
    ctx.beginPath(); ctx.ellipse(0, 2, 27, 9, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = "#3b4659"; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.strokeStyle = "rgba(60,75,100,.55)"; ctx.beginPath(); ctx.ellipse(0, 2, 18, 5.5, 0, 0, TAU); ctx.stroke();
    dome(ctx, 0, -2, 11, 10, "#e1f3ff", "#4d9fe6");
    lights(ctx, [-20, -10, 0, 10, 20], 4.5, t, "#fff6a8");
  },
  comet(ctx, t, n) {                                     // sleek teal dart with speed trail
    glow(ctx, "#22e0d0", 38, .22 + .2 * n);
    for (let i = 0; i < 4; i++) {
      const y = -6 + i * 4.2, len = 20 + ((t * 90 + i * 17) % 18), g = ctx.createLinearGradient(-26, 0, -26 - len, 0);
      g.addColorStop(0, "rgba(120,255,240,.8)"); g.addColorStop(1, "rgba(120,255,240,0)");
      ctx.strokeStyle = g; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(-24, y); ctx.lineTo(-26 - len, y); ctx.stroke();
    }
    ctx.fillStyle = "#0f8f8a"; ctx.beginPath(); ctx.moveTo(-18, -2); ctx.lineTo(-30, -14); ctx.lineTo(-10, -5); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-18, 6); ctx.lineTo(-30, 17); ctx.lineTo(-10, 8); ctx.fill();
    ctx.fillStyle = grad(ctx, -8, 10, [[0, "#c9fff6"], [.45, "#2ec7bb"], [1, "#0b5f66"]]);
    ctx.beginPath(); ctx.ellipse(0, 2, 29, 8.5, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = "#0a4a52"; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,255,.7)"; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(-18, 3); ctx.lineTo(20, 3); ctx.stroke();
    dome(ctx, 6, -2, 9, 8.5, "#eafffb", "#2aa9d8");
    ell(ctx, 28, 2, 2.4, 2, rgba("#ffffff", .6 + .4 * Math.sin(t * 9)));
  },
  nova(ctx, t, n) {                                      // golden hull with orbit ring + gems
    glow(ctx, "#ffc83d", 40, .26 + .22 * n);
    ctx.strokeStyle = rgba("#ffd96b", .55); ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(0, 3, 35, 11, 0, Math.PI, TAU); ctx.stroke();   // ring (back)
    ctx.fillStyle = grad(ctx, -7, 11, [[0, "#fff4c4"], [.45, "#e9b83a"], [1, "#7b4d0e"]]);
    ctx.beginPath(); ctx.ellipse(0, 2, 26, 9.5, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = "#6b440c"; ctx.lineWidth = 1.2; ctx.stroke();
    ["#6af0ff", "#ff7ad9", "#6af0ff", "#ff7ad9", "#6af0ff"].forEach((c, i) => ell(ctx, -16 + i * 8, 4.5, 2, 1.5, rgba(c, .6 + .4 * Math.sin(t * 5 + i))));
    dome(ctx, 0, -2, 10.5, 10, "#fff1c6", "#ff9a2e");
    ctx.strokeStyle = rgba("#fff1a8", .95); ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(0, 3, 35, 11, 0, 0, Math.PI); ctx.stroke();           // ring (front)
    ctx.strokeStyle = "#b07a17"; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(0, 3, 35, 11, 0, 0, Math.PI); ctx.stroke();
  },
  phantom(ctx, t, n) {                                   // dark stealth wing, violet neon
    const p = .5 + .5 * Math.sin(t * 3);
    glow(ctx, "#a35bff", 42, .25 + .25 * p + .15 * n);
    ctx.beginPath(); ctx.moveTo(30, 2); ctx.lineTo(12, -8); ctx.lineTo(-6, -11); ctx.lineTo(-26, -5); ctx.lineTo(-32, 2);
    ctx.lineTo(-26, 9); ctx.lineTo(-6, 12); ctx.lineTo(12, 9); ctx.closePath();
    ctx.fillStyle = grad(ctx, -11, 12, [[0, "#8a76e0"], [.5, "#4a3b96"], [1, "#1c1442"]]); ctx.fill();
    ctx.strokeStyle = rgba("#c08bff", .9); ctx.lineWidth = 1.6; ctx.shadowColor = "#a35bff"; ctx.shadowBlur = 8; ctx.stroke(); ctx.shadowBlur = 0;
    ctx.strokeStyle = rgba("#b784ff", .55); ctx.lineWidth = 1;
    [[-14, -6, -14, 10], [0, -9, 0, 11], [14, -6, 14, 7]].forEach(([a, b, c, d]) => { ctx.beginPath(); ctx.moveTo(a, b); ctx.lineTo(c, d); ctx.stroke(); });
    dome(ctx, 6, -1, 8, 8, "#e6dcff", "#5b46b8");
    ell(ctx, 6, -3, 3, 2, rgba("#d6b8ff", .5 + .4 * p));
    [-3, 7].forEach((y) => ell(ctx, -31, y, 2.6, 1.6, rgba("#e1c7ff", .6 + .4 * p)));
  },
  vortex(ctx, t, n) {                                    // bio-green, spinning dashed ring, swirl bubble
    glow(ctx, "#5dff7a", 40, .25 + .2 * n);
    ctx.fillStyle = "#1e7a3a";
    for (let i = -2; i <= 2; i++) { ctx.beginPath(); ctx.moveTo(i * 9 - 3, 8); ctx.lineTo(i * 9, 15 + (i % 2 ? 0 : 3)); ctx.lineTo(i * 9 + 3, 8); ctx.fill(); }
    ctx.fillStyle = grad(ctx, -8, 11, [[0, "#d9ffd0"], [.45, "#4fd35e"], [1, "#0d5a2a"]]);
    ctx.beginPath(); ctx.ellipse(0, 2, 25, 10, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = "#0b4a22"; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.setLineDash([7, 5]); ctx.lineDashOffset = -t * 40; ctx.strokeStyle = "#caff6a"; ctx.lineWidth = 2.6;
    ctx.beginPath(); ctx.ellipse(0, 2, 19, 6.5, 0, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
    dome(ctx, 0, -2, 11, 11, "#f0fff0", "#3fbf6a");
    ctx.save(); ctx.beginPath(); ctx.ellipse(0, -2, 11, 11, 0, Math.PI, TAU); ctx.clip();
    ctx.strokeStyle = rgba("#1c8f45", .8); ctx.lineWidth = 1.6;
    for (let i = 0; i < 2; i++) { ctx.beginPath(); ctx.arc(0, -3, 3 + i * 3.5, t * 3 + i * 2, t * 3 + i * 2 + 3.6); ctx.stroke(); }
    ctx.restore();
    [[-24, 0, -30, -8], [24, 0, 30, -8]].forEach(([a, b, c, d]) => { ctx.strokeStyle = "#8dffa0"; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(a, b); ctx.lineTo(c, d); ctx.stroke(); ell(ctx, c, d, 2, 2, "#e4ffe0"); });
  },
  eclipse(ctx, t, n) {                                   // black hull, crimson corona, crescent emblem
    const p = .5 + .5 * Math.sin(t * 4);
    glow(ctx, "#ff2f4d", 44, .28 + .22 * p + .12 * n);
    ctx.strokeStyle = rgba("#ff3a55", .8); ctx.lineWidth = 2.2; ctx.shadowColor = "#ff2f4d"; ctx.shadowBlur = 7;
    [-1, 1].forEach((s) => { ctx.beginPath(); ctx.moveTo(s * 22, 1); ctx.quadraticCurveTo(s * 33, -2, s * 31, -13); ctx.stroke(); });
    ctx.shadowBlur = 0;
    ctx.fillStyle = grad(ctx, -8, 11, [[0, "#454a5c"], [.45, "#14161f"], [1, "#050509"]]);
    ctx.beginPath(); ctx.ellipse(0, 2, 27, 10, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = rgba("#ff3a55", .6 + .4 * p); ctx.lineWidth = 1.6; ctx.stroke();
    ctx.fillStyle = rgba("#ff3a55", .5 + .4 * p); ctx.fillRect(-18, 5.5, 36, 1.8);
    dome(ctx, 0, -2, 10, 10, "#2a2d3d", "#07080d");
    ell(ctx, 0, -7, 6, 6, "#ff3a55"); ell(ctx, 2.4, -8, 5.2, 5.2, "#0b0c12");                         // crescent
    lights(ctx, [-20, -12, 12, 20], 2.5, t, "#ff6a80", 1.5);
  },
  aurora(ctx, t, n) {                                    // iridescent flagship: shifting colours, crown, orbiting sparkles
    const h = (t * 50) % 360, c = (o, l = 62) => `hsl(${(h + o) % 360},90%,${l}%)`;
    const aura = ctx.createRadialGradient(0, 4, 4, 0, 4, 50);
    aura.addColorStop(0, `hsla(${h},95%,70%,${.38 + .15 * n})`); aura.addColorStop(.6, `hsla(${(h + 90) % 360},95%,65%,.14)`); aura.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = aura; ctx.beginPath(); ctx.arc(0, 4, 50, 0, TAU); ctx.fill();
    const hull = ctx.createLinearGradient(-28, 0, 28, 0);
    [0, .25, .5, .75, 1].forEach((s, i) => hull.addColorStop(s, c(i * 55, 70)));
    ctx.fillStyle = hull; ctx.beginPath(); ctx.ellipse(0, 2, 28, 10, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = grad(ctx, -8, 12, [[0, "rgba(255,255,255,.55)"], [.5, "rgba(255,255,255,0)"], [1, "rgba(0,0,0,.35)"]]);
    ctx.beginPath(); ctx.ellipse(0, 2, 28, 10, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,.85)"; ctx.lineWidth = 1.3; ctx.stroke();
    ctx.fillStyle = "#fff3b0";                                                                          // crown
    [-14, -7, 0, 7, 14].forEach((x, i) => { const hh = i === 2 ? 9 : 6; ctx.beginPath(); ctx.moveTo(x - 2.5, -4); ctx.lineTo(x, -4 - hh); ctx.lineTo(x + 2.5, -4); ctx.fill(); ell(ctx, x, -5 - hh, 1.4, 1.4, c(i * 70, 75)); });
    dome(ctx, 0, -1, 11, 10, "#ffffff", "#ffe9a8");
    for (let i = 0; i < 6; i++) {                                                                       // orbiting sparkles
      const a = t * 2.2 + i * TAU / 6, x = Math.cos(a) * 36, y = 3 + Math.sin(a) * 12, k = (Math.sin(a) + 1) / 2;
      ctx.globalAlpha = .45 + .55 * k; ell(ctx, x, y, 1.8 + k, 1.8 + k, c(i * 60, 80));
    }
    ctx.globalAlpha = 1;
  },
};
export const UFO_IDS = Object.keys(UFO);

export function drawUfo(ctx, id, t, night = 0) {
  ctx.save(); (UFO[id] || UFO.scout)(ctx, t, night); ctx.restore();
}
