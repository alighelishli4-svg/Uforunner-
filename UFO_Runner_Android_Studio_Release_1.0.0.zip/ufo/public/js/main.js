import { tg, api, initData } from "./api.js?v=12";
import { S, takeServerState, currentUfo } from "./state.js";
import { T, fmt } from "./i18n.js";
import { $, toast } from "./ui.js";
import { clamp, rand } from "./utils.js";
import { initSky, resetCycle, stepSky, drawSky, nightFactor } from "./sky.js";
import { JET_TYPES, JET_SIZE, drawJet } from "./jets.js";
import { OBSTACLES, MINE, spawnObstacle, updateObstacle, drawObstacle } from "./obstacles.js";
import { drawUfo } from "./ufos.js";
import { initShop, openShop, renderShop } from "./shop.js";
import { openWallet, closeWallet } from "./ton.js";

tg?.ready(); tg?.expand();
if (!CanvasRenderingContext2D.prototype.roundRect)
  CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h) { this.rect(x, y, w, h); };

const canvas = $("game"), ctx = canvas.getContext("2d");
const home = $("home"), gameover = $("gameover");

let runId = null, busy = false, last = 0, gameT = 0, score = 0, runCoins = 0;
let spawnTimer = 0, aircraftTimer = 0, coinTimer = 0, idleScore = 0, idleId = 0, idleLast = 0;
let obstacles = [], aircraft = [], coins = [], particles = [], beam = null, banner = null;
let keys = {}, pointerHeld = false;
const thrustPointers = new Set();                 // fingers currently holding "thrust"
const LASER_COOLDOWN = 1.1;                       // seconds between manual laser shots
const FIRE_ZONE = 0.62;                           // right ~38% of the screen = laser button (only if the laser is owned)
const LIFE_INVULN = 2.2;                          // seconds of immunity after the extra life is used
let run = null;                                   // per-run snapshot of the chosen UFO + upgrades
const player = { x: 100, y: 250, w: 44, h: 24, vy: 0 };

// ---------- canvas ----------
function resize() {
  const r = canvas.getBoundingClientRect(), dpr = Math.min(devicePixelRatio || 1, 2);
  canvas.width = Math.floor(r.width * dpr); canvas.height = Math.floor(r.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
addEventListener("resize", () => { resize(); initSky(canvas.clientWidth, canvas.clientHeight); });
resize(); initSky(canvas.clientWidth, canvas.clientHeight);

// ---------- menu UI ----------
function upgradeCardHtml(label, level) {
  const t = T();
  if (level >= S.config.max_level) return `${label}<br><small>${t.level} ${level}/${S.config.max_level} · <b>${t.max}</b></small>`;
  return `${label}<br><small>${t.level} ${level}/${S.config.max_level} · ${t.upgrade}: <b>${S.config.costs[level - 1]} 🪙</b></small>`;
}
const card = (f) => document.querySelector(`[data-feature="${f}"]`);

// Stars-only feature card: owned always wins; otherwise buyable when the admin enabled it, else "coming later".
function starsCard(feature, label, ownedText, buyText, note1, note2 = "") {
  const t = T(), c = card(feature), u = S.user, item = S.stars.items[feature];
  const small = (txt, warn) => (txt ? `<small${warn ? ' class="warn"' : ""}>${txt}</small>` : "");
  if (u?.[feature]) { c.innerHTML = `${label}<br><small>${ownedText}</small>${small(note1)}${small(note2, true)}`; c.disabled = true; c.classList.remove("locked"); }
  else if (S.stars.enabled && item?.enabled) { c.innerHTML = `${label}<br><small>${buyText}: <b>⭐ ${item.stars}</b></small>${small(note1)}${small(note2, true)}`; c.disabled = false; c.classList.remove("locked"); }
  else { c.innerHTML = `${label}<br><small>${t.coming}</small>`; c.disabled = true; c.classList.add("locked"); }
}

function render() {
  const t = T(), u = S.user;
  document.documentElement.dir = S.language === "fa" ? "rtl" : "ltr";
  document.documentElement.lang = S.language;
  $("title").textContent = t.title;
  $("userLine").innerHTML = `${t.best}: <b id="best">${fmt(u?.best_score)}</b>`;
  $("best2").textContent = fmt(u?.best_score); $("bestLabel").textContent = t.bestLabel;
  $("coinsHead").textContent = fmt(u?.coins);
  $("play").textContent = t.play; $("again").textContent = t.again; $("menu").textContent = t.menu;
  $("shopBtn").textContent = t.shop; $("walletBtn").classList.toggle("hidden", !S.fun.enabled); $("welcome").textContent = t.ready; $("goTitle").textContent = t.gameover;
  $("scoreLabel").textContent = t.score; $("coinsLabel").textContent = t.coins; $("goal").textContent = t.goal;
  $("lang").textContent = S.language === "en" ? "FA" : "EN";
  if (!S.running) $("status").textContent = t.ready_s;

  const sl = u?.speed_level || 1, ml = u?.maneuver_level || 1;
  card("speed").innerHTML = upgradeCardHtml(t.speed, sl);
  card("maneuver").innerHTML = upgradeCardHtml(t.maneuver, ml);
  for (const [f, lvl] of [["speed", sl], ["maneuver", ml]]) {
    card(f).classList.toggle("maxed", lvl >= S.config.max_level);
    card(f).classList.toggle("poor", lvl < S.config.max_level && (u?.coins || 0) < S.config.costs[lvl - 1]);
  }
  starsCard("laser", t.laser, t.owned, t.buyLaser, `${t.laserHow}`, t.laserNote);
  starsCard("extra_life", t.extra, t.owned, t.buy, t.extraNote);

  if (!$("shop").classList.contains("hidden")) renderShop();
}

async function buyUpgrade(key) {
  if (busy || S.running || !S.user) return;
  if (key === "laser" || key === "extra_life") { return buyStarsDirect(key); }
  else {
    const lvl = key === "speed" ? S.user.speed_level : S.user.maneuver_level;
    if (lvl >= S.config.max_level) return;
    if (S.user.coins < S.config.costs[lvl - 1]) return toast(T().poor);
  }
  busy = true;
  try { takeServerState(await api("/api/upgrade", { key })); toast(T().bought); } catch { toast(T().poor); }
  busy = false; render();
}

async function buyStarsDirect(item){ if(!tg?.openInvoice)return toast(T().openTg); try{const {link}=await api("/api/stars/invoice",{item});tg.openInvoice(link,status=>{if(status==="paid"){toast(T().paid);setTimeout(async()=>{try{takeServerState(await api("/api/me"));}catch{}render();},900);}else if(status==="cancelled")toast(T().cancelled);});}catch{toast(T().fail);} }

// ---------- spawning ----------
function spawnAircraft() {
  const r = Math.random();
  const type = r < .20 ? "F-14" : r < .60 ? "GENERIC_A" : "GENERIC_B";
  aircraft.push({ x: canvas.clientWidth + 70, y: 60 + Math.random() * (canvas.clientHeight - 120), w: JET_SIZE.w, h: JET_SIZE.h, type, vx: 220 + Math.random() * 90 });
}
function spawnCoins() {
  const h = canvas.clientHeight, w = canvas.clientWidth, count = 1 + Math.floor(Math.random() * 4);
  let y = 60;
  for (let tries = 0; tries < 8; tries++) {                       // pick a lane not blocked by a fresh obstacle
    y = 55 + Math.random() * (h - 110);
    if (!obstacles.some((o) => o.x > w - 90 && Math.abs(o.y - y) < o.h / 2 + 24)) break;
  }
  for (let i = 0; i < count; i++) coins.push({ x: w + 40 + i * 34, y, r: 11, phase: Math.random() * 6 });
}
function boom(x, y, colors = ["#ffd45e", "#ff8a1c", "#fff2a8"]) {
  for (let i = 0; i < 16; i++) { const a = Math.random() * 6.283, s = rand(40, 190); particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: rand(.3, .65), max: .65, c: colors[i % colors.length] }); }
}
function fireLaser() {
  beam = { y: player.y, life: .16 };
  for (const o of obstacles) {
    if (o.x > player.x + 10 && o.x - o.w / 2 < player.x + 380 && Math.abs(o.y - player.y) < o.h * .45 + 4) {
      if (OBSTACLES[o.type].destructible) { o.dead = true; boom(o.x, o.y); }
      else boom(o.x - o.w / 2, player.y, ["#ffffff", "#9fd0ff"]);   // armored: just sparks
    }
  }
  obstacles = obstacles.filter((o) => !o.dead);
}
// Manual shot: right side of the screen (or F / Enter / → on keyboard, right-click with a mouse).
function tryFireLaser() {
  if (!S.running || !run?.laser || run.laserCd > 0) return false;
  run.laserCd = LASER_COOLDOWN; fireLaser(); return true;
}
// Every deadly contact goes through here. Returns true if the run just ended.
function lethal(thing, kind) {
  if (run.invuln > 0) return false;                               // still protected after losing the extra life
  if (run.lives > 0) {
    run.lives--; run.invuln = LIFE_INVULN;
    boom(player.x, player.y, ["#ff7a9c", "#ffd0dc", "#ffffff"]);
    banner = { text: T().lifeUsed, life: 2.5 };
    if (kind === "obstacle") obstacles = obstacles.filter((o) => o !== thing);
    else if (kind === "jet") aircraft = aircraft.filter((a) => a !== thing);
    return false;
  }
  finish(); return true;
}

// ---------- drawing helpers ----------
function drawCoin(c) {
  const sq = Math.abs(Math.sin(c.phase)) * 0.6 + 0.4;
  ctx.save(); ctx.translate(c.x, c.y);
  ctx.fillStyle = "#ffcf33"; ctx.beginPath(); ctx.ellipse(0, 0, c.r * sq, c.r, 0, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = "#b8860b"; ctx.lineWidth = 2; ctx.stroke();
  ctx.fillStyle = "#fff4b0"; ctx.beginPath(); ctx.ellipse(-c.r * .25 * sq, -c.r * .3, c.r * .25 * sq, c.r * .3, 0, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}
function drawHUD() {
  ctx.save(); ctx.shadowColor = "rgba(0,0,0,.65)"; ctx.shadowBlur = 4; ctx.textAlign = "left"; ctx.font = "bold 16px sans-serif";
  ctx.fillStyle = "#fff"; ctx.fillText(`SCORE ${Math.floor(score)}`, 14, 25); ctx.fillText("GOAL 1,000,000", 14, 46);
  ctx.fillStyle = "#ffd45e"; ctx.fillText(`🪙 ${runCoins}`, 14, 67);
  if (run?.hasLife) { ctx.textAlign = "right"; ctx.fillStyle = "#fff"; ctx.fillText(run.lives > 0 ? "❤️" : "🖤", canvas.clientWidth - 14, 25); ctx.textAlign = "left"; }
  if (banner) {
    const w = Math.min(canvas.clientWidth - 24, 330), x = (canvas.clientWidth - w) / 2;
    ctx.globalAlpha = Math.min(1, banner.life); ctx.shadowBlur = 0;
    ctx.fillStyle = "rgba(20,10,10,.82)"; ctx.beginPath(); ctx.roundRect(x, 84, w, 38, 10); ctx.fill();
    ctx.strokeStyle = "#ff7a4a"; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = "#ffd9c7"; ctx.font = "bold 12px system-ui,sans-serif"; ctx.textAlign = "center"; ctx.fillText(banner.text, canvas.clientWidth / 2, 107, w - 16);
  }
  ctx.restore();
  if (run?.laser) drawLaserButton();
}
function drawLaserButton() {
  const w = canvas.clientWidth, h = canvas.clientHeight, zx = w * FIRE_ZONE, cx = (zx + w) / 2, cy = h - 56, r = 27;
  const ready = run.laserCd <= 0, prog = ready ? 1 : 1 - run.laserCd / LASER_COOLDOWN;
  ctx.save();
  ctx.fillStyle = "rgba(255,70,70,.05)"; ctx.fillRect(zx, 0, w - zx, h);                       // faint fire zone
  ctx.strokeStyle = "rgba(255,120,120,.25)"; ctx.setLineDash([6, 8]); ctx.beginPath(); ctx.moveTo(zx, 0); ctx.lineTo(zx, h); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle = ready ? "rgba(255,60,60,.38)" : "rgba(60,20,20,.5)"; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.fill();
  ctx.lineWidth = 4; ctx.strokeStyle = ready ? "#ff6b6b" : "#ffb27a"; ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + prog * Math.PI * 2); ctx.stroke();
  ctx.font = "bold 20px sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillStyle = "#fff"; ctx.fillText("🔴", cx, cy + 1);
  ctx.restore();
}
const overlap = (a, b, k = 1) => Math.abs(a.x - b.x) < (a.w + b.w * k) / 2 && Math.abs(a.y - b.y) < (a.h + b.h * k) / 2;

// ---------- idle sky behind the menu ----------
function startIdle() { if (!idleId) { idleLast = performance.now(); resetCycle(); idleScore = 0; idleId = requestAnimationFrame(idleLoop); } }
function idleLoop(now) {
  idleId = 0; if (S.running) return;
  const dt = Math.min(.05, (now - idleLast) / 1000); idleLast = now; idleScore += 130 * dt;
  stepSky(dt, 120, idleScore); drawSky(ctx, now / 1000);
  idleId = requestAnimationFrame(idleLoop);
}

// ---------- game flow ----------
async function start() {
  if (busy || S.running) return;
  if (!initData && !window.AndroidUFO?.isAndroidApp?.()) return toast(T().openTg);
  busy = true;
  document.querySelectorAll(".panel").forEach((p) => p.classList.add("hidden"));
  try {
    const data = await api("/api/start");
    takeServerState(data); runId = data.run_id;
    const ufo = currentUfo();
    run = { ufo, speedLevel: S.user.speed_level || 1, maneuverLevel: S.user.maneuver_level || 1,
            laser: !!S.user.laser, laserCd: 0.4, mineWarned: false,
            hasLife: !!S.user.extra_life, lives: S.user.extra_life ? 1 : 0, invuln: 0 };
    thrustPointers.clear(); pointerHeld = false;
    score = 0; runCoins = 0; gameT = 0; obstacles = []; aircraft = []; coins = []; particles = []; beam = null; banner = null;
    resize(); player.y = canvas.clientHeight / 2; player.vy = 0;
    if (run.laser) banner = { text: T().laserHint, life: 4 };
    spawnTimer = 0; aircraftTimer = 0; coinTimer = 0.6; resetCycle();
    S.running = true; last = performance.now(); $("status").textContent = T().running;
    requestAnimationFrame(loop);
  } catch { toast(T().failStart); home.classList.remove("hidden"); }
  busy = false;
}

async function finish() {
  S.running = false; $("status").textContent = T().gameover.toUpperCase();
  $("finalScore").textContent = fmt(Math.floor(score)); $("finalCoins").textContent = fmt(runCoins); $("validation").textContent = "";
  gameover.classList.remove("hidden"); startIdle();
  try {
    const data = await api("/api/finish", { run_id: runId, score: Math.floor(score), coins: runCoins });
    S.user = data.user; $("validation").textContent = data.valid ? T().saved : T().invalid;
    if (!data.valid) $("finalCoins").textContent = fmt(0);
  } catch { $("validation").textContent = T().failSave; }
  render();
}

function loop(now) {
  if (!S.running) return;
  const dt = Math.min(.032, (now - last) / 1000); last = now; gameT += dt;
  const w = canvas.clientWidth, h = canvas.clientHeight, u = run.ufo;

  // Controls: hold (touch / Up / W / Space) = thrust up, else gravity. Maneuver upgrade + UFO bonus = snappier.
  const accel = 700 + (run.maneuverLevel - 1) * 90 + u.maneuver;
  const maxV = 320 + (run.maneuverLevel - 1) * 28 + u.maneuver * 0.12;
  const up = pointerHeld || keys["ArrowUp"] || keys["w"] || keys[" "], down = keys["ArrowDown"] || keys["s"];
  player.vy += (up ? -accel : down ? accel : accel * 0.55) * dt;
  player.vy *= Math.pow(.90, dt * 60); player.vy = clamp(player.vy, -maxV, maxV);
  player.y += player.vy * dt;
  if (run.invuln > 0) run.invuln -= dt;
  if (player.y < 25 || player.y > h - 25) {
    if (lethal(null, "wall")) return;
    player.y = clamp(player.y, 26, h - 26); player.vy = 0;        // survived thanks to the extra life: bounce back in
  }

  score += 180 * dt * (1 + run.speedLevel * .04 + u.speed);       // Speed upgrade + UFO speed = faster score gain
  spawnTimer += dt; aircraftTimer += dt; coinTimer -= dt;
  if (spawnTimer > Math.max(.5, 1.15 - score / 1000000 * .45)) { spawnTimer = 0; const o = spawnObstacle(score, w, h); obstacles.push(o);
    if (o.type === MINE && !run.mineWarned) { run.mineWarned = true; if (run.laser) banner = { text: T().mineWarn, life: 4 }; } }
  if (aircraftTimer > Math.max(.9, 2.2 - score / 1000000)) { aircraftTimer = 0; spawnAircraft(); }
  if (coinTimer <= 0) { coinTimer = 1.1 + Math.random() * 0.8; spawnCoins(); }

  const worldSpeed = 260 * (1 + score / 1000000);
  obstacles.forEach((o) => updateObstacle(o, dt, worldSpeed));
  aircraft.forEach((a) => (a.x -= a.vx * dt));
  coins.forEach((c) => { c.x -= worldSpeed * dt; c.phase += dt * 6; });
  obstacles = obstacles.filter((o) => o.x > -120); aircraft = aircraft.filter((a) => a.x > -120); coins = coins.filter((c) => c.x > -30);

  if (run.laser && run.laserCd > 0) run.laserCd -= dt;            // manual fire: see tryFireLaser()
  if (beam) { beam.life -= dt; if (beam.life <= 0) beam = null; }
  if (banner) { banner.life -= dt; if (banner.life <= 0) banner = null; }
  particles.forEach((p) => { p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt; }); particles = particles.filter((p) => p.life > 0);

  for (const o of obstacles) if (overlap(player, o, .8)) { if (lethal(o, "obstacle")) return; break; }
  for (const a of aircraft) if (a.type === "F-14" && overlap(player, a)) { if (lethal(a, "jet")) return; break; }   // the other jets are harmless
  coins = coins.filter((c) => {
    if (Math.abs(c.x - player.x) < player.w / 2 + c.r && Math.abs(c.y - player.y) < player.h / 2 + c.r + 4) { runCoins++; return false; }
    return true;
  });
  if (score >= 1000000) { score = 1000000; return finish(); }

  stepSky(dt, worldSpeed, score); drawSky(ctx, gameT);
  coins.forEach(drawCoin); obstacles.forEach((o) => drawObstacle(ctx, o, gameT)); aircraft.forEach((a) => drawJet(ctx, a, gameT));
  if (beam) {
    ctx.save(); ctx.globalAlpha = Math.min(1, beam.life / .16 + .2); ctx.lineCap = "round";
    ctx.strokeStyle = "rgba(255,60,60,.35)"; ctx.lineWidth = 9; ctx.beginPath(); ctx.moveTo(player.x + 26, beam.y); ctx.lineTo(player.x + 380, beam.y); ctx.stroke();
    ctx.strokeStyle = "#ffe3e3"; ctx.lineWidth = 2.5; ctx.stroke(); ctx.restore();
  }
  for (const p of particles) { ctx.globalAlpha = Math.max(0, p.life / p.max); ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(p.x, p.y, 2.6, 0, 7); ctx.fill(); }
  ctx.globalAlpha = 1;
  ctx.save(); ctx.translate(player.x, player.y); ctx.rotate(clamp(player.vy / 1600, -.18, .18));
  if (run.invuln > 0) ctx.globalAlpha = Math.floor(gameT * 12) % 2 ? .4 : 1;               // blink while protected
  drawUfo(ctx, u.id, gameT, nightFactor());
  if (run.invuln > 0) { ctx.strokeStyle = "rgba(255,120,160,.85)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, 32, 0, 7); ctx.stroke(); }
  ctx.restore();
  drawHUD();
  requestAnimationFrame(loop);
}

// ---------- input ----------
// Left part of the screen (or the whole screen if there is no laser) = thrust. Right part = fire the laser.
function onPointerDown(id, xFrac) {
  if (S.running && run?.laser && xFrac >= FIRE_ZONE) return tryFireLaser();
  thrustPointers.add(id); pointerHeld = true;
}
function onPointerUp(id) { thrustPointers.delete(id); pointerHeld = thrustPointers.size > 0; }
document.addEventListener("keydown", (e) => {
  keys[e.key] = true; if (e.key === " ") e.preventDefault();
  if (!e.repeat && (e.key === "f" || e.key === "F" || e.key === "Enter" || e.key === "ArrowRight")) tryFireLaser();
});
document.addEventListener("keyup", (e) => (keys[e.key] = false));
canvas.addEventListener("pointerdown", (e) => { const r = canvas.getBoundingClientRect(); onPointerDown(e.pointerId, (e.clientX - r.left) / r.width); });
addEventListener("pointerup", (e) => onPointerUp(e.pointerId));
canvas.addEventListener("pointercancel", (e) => onPointerUp(e.pointerId));
canvas.addEventListener("contextmenu", (e) => { e.preventDefault(); tryFireLaser(); });   // desktop: right-click fires

$("play").onclick = start; $("again").onclick = start;
$("menu").onclick = () => { gameover.classList.add("hidden"); home.classList.remove("hidden"); render(); };
$("shopBtn").onclick = openShop;
$("walletBtn").onclick = openWallet;
$("walletBack").onclick = closeWallet;
card("speed").onclick = () => buyUpgrade("speed");
card("maneuver").onclick = () => buyUpgrade("maneuver");
card("laser").onclick = () => buyUpgrade("laser");
card("extra_life").onclick = () => buyUpgrade("extra_life");
$("lang").onclick = async () => {
  S.language = S.language === "en" ? "fa" : "en"; render();
  try { await api("/api/language", { language: S.language }); } catch {}
};
initShop(render);

// ---------- boot ----------
(async () => {
  startIdle(); render();
  if (!initData && !window.AndroidUFO?.isAndroidApp?.()) { $("status").textContent = T().openTg; return; }
  try { takeServerState(await api("/api/me")); S.language = S.user.language || "en"; } catch { toast("Server error"); }
  render();
})();

// Exposed for the headless test only.
globalThis.__ufo = { start, player, spawnObstacle, onPointerDown, onPointerUp, tryFireLaser, get run() { return run; }, get beam() { return beam; }, setScore: (v) => (score = v), get banner() { return banner; }, get night() { return nightFactor(); }, get score() { return score; }, get running() { return S.running; }, get aircraft() { return aircraft; }, get obstacles() { return obstacles; }, get coins() { return coins; }, drawJet, drawUfo, drawObstacle, OBSTACLES, JET_TYPES };
