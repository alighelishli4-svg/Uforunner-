// Fighter jets (plan view, nose to the left). Each has its own silhouette, livery, flame colour and painted designation.
// Outline = upper half nose->tail, mirrored. Only the F-14 is hostile (collision handled in main.js).
const JETS = {
  "F-14": { // swept wings, twin fins, navy tail band
    pts: [[-34,0],[-27,-2],[-15,-4],[-7,-5],[15,-18],[20,-18],[22,-7],[29,-10],[34,-9],[34,-4],[37,-3],[37,0]],
    tail: 37, canopy: -19, base: "#c3cbd8", belly: "#7e8aa0", edge: "#4a5468", stripe: "#2d5fb8", camo: [], camoColor: "",
    flame: ["#ffe08a", "#ff7a1c"], twin: false, designation: true },
  "GENERIC_A": { // anonymous compact single-engine aircraft silhouette
    pts: [[-32,0],[-21,-3],[-9,-5],[-1,-6],[11,-15],[19,-15],[19,-8],[25,-8],[29,-10],[31,-9],[31,-3],[33,0]],
    tail: 33, canopy: -17, base: "#8e98a8", belly: "#59627a", edge: "#333a4c", stripe: "#aeb8c8", camo: [], camoColor: "",
    flame: ["#e6f4ff", "#5ab2ff"], twin: false, designation: false },
  "GENERIC_B": { // anonymous twin-engine aircraft silhouette
    pts: [[-36,0],[-28,-2],[-16,-4],[-8,-6],[2,-8],[10,-20],[22,-20],[24,-9],[30,-9],[32,-13],[38,-13],[38,-5],[41,-4],[41,0]],
    tail: 41, canopy: -21, base: "#c9cbd1", belly: "#777f8c", edge: "#454b55", stripe: "#9aa3ad", camo: [], camoColor: "",
    flame: ["#ffd48a", "#ff8a3d"], twin: true, designation: false },
};
for (const j of Object.values(JETS)) j.tip = j.pts.reduce((m, p) => (Math.abs(p[1]) > Math.abs(m[1]) ? p : m), j.pts[0]);

export const JET_TYPES = Object.keys(JETS);
export const JET_SIZE = { w: 62, h: 26 };

function trace(ctx, j) {
  ctx.beginPath(); ctx.moveTo(j.pts[0][0], j.pts[0][1]);
  for (const [x, y] of j.pts.slice(1)) ctx.lineTo(x, y);
  for (const [x, y] of [...j.pts].reverse()) ctx.lineTo(x, -y);
  ctx.closePath();
}

export function drawJet(ctx, a, t) {
  const j = JETS[a.type];
  ctx.save(); ctx.translate(a.x, a.y);

  const len = 20 + Math.random() * 6;                                   // afterburner
  for (const oy of (j.twin ? [-4, 4] : [0])) {
    const g = ctx.createLinearGradient(j.tail, 0, j.tail + len, 0);
    g.addColorStop(0, j.flame[0]); g.addColorStop(.5, j.flame[1]); g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g; ctx.beginPath();
    ctx.moveTo(j.tail - 2, oy - 2.6); ctx.lineTo(j.tail + len, oy); ctx.lineTo(j.tail - 2, oy + 2.6); ctx.fill();
  }

  trace(ctx, j);                                                          // body with vertical shading
  const body = ctx.createLinearGradient(0, -18, 0, 18);
  body.addColorStop(0, j.base); body.addColorStop(.5, "#eef2f8"); body.addColorStop(1, j.belly);
  ctx.fillStyle = body; ctx.fill();

  ctx.save(); trace(ctx, j); ctx.clip();                                  // camo patches + tail band
  ctx.fillStyle = j.camoColor || "rgba(0,0,0,0)";
  for (const [x, y, rx, ry] of j.camo) { ctx.beginPath(); ctx.ellipse(x, y, rx, ry, .2, 0, 7); ctx.fill(); }
  ctx.fillStyle = j.stripe; ctx.fillRect(j.tail - 10, -22, 5, 44);
  ctx.restore();

  trace(ctx, j); ctx.lineWidth = 1.2; ctx.strokeStyle = j.edge; ctx.stroke();
  ctx.beginPath(); ctx.moveTo(j.pts[0][0] + 6, 0); ctx.lineTo(j.tail - 4, 0); ctx.lineWidth = .8; ctx.stroke();   // spine
  ctx.fillStyle = "#1a2030";                                                                                    // intakes
  ctx.beginPath(); ctx.ellipse(-5, -3.3, 5, 1.6, 0, 0, 7); ctx.ellipse(-5, 3.3, 5, 1.6, 0, 0, 7); ctx.fill();
  ctx.fillStyle = j.canopyColor || "rgba(50,110,170,.92)";                                                      // canopy
  ctx.beginPath(); ctx.ellipse(j.canopy, 0, 7, 2.7, 0, 0, 7); ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,.4)"; ctx.beginPath(); ctx.ellipse(j.canopy - 1.5, -.8, 3, 1, 0, 0, 7); ctx.fill();

  if (Math.sin(t * 7 + a.y) > 0) {                                        // wing-tip nav lights
    ctx.fillStyle = "#ff4040"; ctx.beginPath(); ctx.arc(j.tip[0], -j.tip[1], 1.6, 0, 7); ctx.fill();
    ctx.fillStyle = "#40ff70"; ctx.beginPath(); ctx.arc(j.tip[0], j.tip[1], 1.6, 0, 7); ctx.fill();
  }

  if (j.designation) {
    ctx.font = "bold 8px system-ui,sans-serif"; ctx.textAlign = "center";
    ctx.lineWidth = 2.4; ctx.strokeStyle = "rgba(0,0,0,.75)"; ctx.strokeText("F-14", 8, 3);
    ctx.fillStyle = "#fff"; ctx.fillText("F-14", 8, 3);
  }
  ctx.restore();
}
