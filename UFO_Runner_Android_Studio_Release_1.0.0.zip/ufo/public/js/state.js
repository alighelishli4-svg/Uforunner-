// Shared client state. Everything the server sends lands here.
export const S = {
  user: null,
  settings: {},
  fun: { enabled: false, tokenAddress: "", decimals: 9, buyUrl: "", note: "", network: "TON" },
  stars: { enabled: false, items: { laser: { stars: 50, enabled: false }, extra_life: { stars: 75, enabled: false } } },
  config: { max_level: 10, laser_cost: 300, costs: [20, 40, 60, 80, 100, 120, 140, 160, 180], ufos: [{ id: "scout", speed: 0, maneuver: 0, price: 0, name: { en: "Scout", fa: "پیشاهنگ" } }] },
  language: "en",
  running: false,
};
export function takeServerState(d) {
  if (d.user) S.user = d.user;
  if (d.settings) S.settings = d.settings;
  if (d.fun) S.fun = d.fun;
  if (d.stars) S.stars = d.stars;
  if (d.config?.costs) S.config = d.config;
}
export const currentUfo = () => S.config.ufos.find((u) => u.id === S.user?.selected_ufo) || S.config.ufos[0];
