import { S } from "./state.js";

const TXT = {
  en: {
    title: "🛸 UFO RUNNER", best: "Best", play: "PLAY", ready: "Ready?", again: "PLAY AGAIN", menu: "MENU", back: "BACK",
    goal: "1,000,000 = FINAL GOAL", gameover: "GAME OVER", score: "Score", coins: "Coins", bestLabel: "Best score",
    speed: "⚡ Speed", maneuver: "🌀 Maneuver", extra: "❤️ Extra Life", laser: "🔴 Laser",
    coming: "Coming later", level: "Lv", max: "MAX", upgrade: "Upgrade", owned: "Equipped ✓", buyLaser: "Buy",
    laserNote: "Can't destroy ☢ Armored Mines", laserHow: "Tap the right side of the screen to fire", laserHint: "🔴 Tap the right side of the screen to fire the laser", extraNote: "Survive one crash per run", lifeUsed: "❤️ Extra life used! You are protected for a moment", mineWarn: "☢ Armored Mines can't be destroyed by laser — dodge them!",
    invalid: "Score rejected by anti-cheat validation.", saved: "Saved.", poor: "Not enough coins", poorFun: "Not enough FUN", funSoon: "FUN is not launched yet", funSalesSoon: "FUN UFO purchases are locked until on-chain payment verification is configured",
    bought: "Done!", openTg: "Open this game from Telegram.", running: "RUNNING", ready_s: "Ready",
    failStart: "Could not start game.", failSave: "Server validation failed.",
    shop: "🛸 SHOP", shopTitle: "UFO SHOP", select: "SELECT", selected: "SELECTED ✓", buy: "BUY", speedStat: "Speed", manStat: "Maneuver",
    funTitle: "💎 FUN Wallet", walletDisconnected: "TON wallet not connected", walletConnected: "Connected", walletUnavailable: "TON Connect could not be loaded", walletAccount: "Wallet", funBalance: "FUN balance", balanceAfterLaunch: "Available after token launch + chain indexer setup", tokenNotConfigured: "Not configured yet", disconnectWallet: "Disconnect wallet", walletSettlement: "FUN is acquired externally on Blum Memepad; the game does not sell FUN.", funNetwork: "Network", funContract: "Jetton master", funBuy: "Open Blum Memepad", starsTitle: "⭐ Special Features", starsSoon: "Special features are coming soon", paid: "Payment received! Updating…",
    cancelled: "Payment cancelled", blum: "Open Blum launchpad", fail: "Something went wrong",
    ufo: { scout: "Scout", comet: "Comet", nova: "Nova", phantom: "Phantom", vortex: "Vortex", eclipse: "Eclipse", aurora: "Aurora" },
  },
  fa: {
    title: "🛸 فرار یوفو", best: "بهترین امتیاز", play: "شروع بازی", ready: "آماده‌ای؟", again: "دوباره", menu: "منو", back: "بازگشت",
    goal: "۱٬۰۰۰٬۰۰۰ = هدف نهایی", gameover: "پایان بازی", score: "امتیاز", coins: "سکه", bestLabel: "بهترین امتیاز",
    speed: "⚡ سرعت", maneuver: "🌀 مانور", extra: "❤️ جان اضافه", laser: "🔴 لیزر",
    coming: "به‌زودی", level: "سطح", max: "حداکثر", upgrade: "ارتقا", owned: "نصب شد ✓", buyLaser: "خرید",
    laserNote: "مین زرهی ☢ را نابود نمی‌کند", laserHow: "برای شلیک، سمت راست صفحه را لمس کن", laserHint: "🔴 برای شلیک لیزر، سمت راست صفحه را لمس کن", extraNote: "در هر بازی یک برخورد را تحمل می‌کنی", lifeUsed: "❤️ جان اضافه مصرف شد! لحظه‌ای محافظت می‌شوی", mineWarn: "☢ مین‌های زرهی با لیزر نابود نمی‌شوند — از آنها فرار کن!",
    invalid: "امتیاز توسط بررسی ضدتقلب رد شد.", saved: "ذخیره شد.", poor: "سکه کافی نیست", poorFun: "FUN کافی نیست", funSoon: "FUN هنوز عرضه نشده است", funSalesSoon: "خرید یوفو با FUN تا راه‌اندازی تأیید پرداخت واقعی TON غیرفعال است",
    bought: "انجام شد!", openTg: "بازی را از داخل تلگرام باز کنید.", running: "در حال بازی", ready_s: "آماده",
    failStart: "شروع بازی ممکن نشد.", failSave: "ثبت نتیجه در سرور ناموفق بود.",
    shop: "🛸 فروشگاه", shopTitle: "فروشگاه یوفو", select: "انتخاب", selected: "انتخاب‌شده ✓", buy: "خرید", speedStat: "سرعت", manStat: "مانور",
    funTitle: "💎 کیف پول FUN", walletDisconnected: "کیف پول TON متصل نیست", walletConnected: "متصل‌شده", walletUnavailable: "اتصال TON Connect بارگذاری نشد", walletAccount: "کیف پول", funBalance: "موجودی FUN", balanceAfterLaunch: "پس از لانچ توکن و اتصال سرویس بررسی زنجیره نمایش داده می‌شود", tokenNotConfigured: "هنوز تنظیم نشده", disconnectWallet: "قطع اتصال کیف پول", walletSettlement: "توکن FUN خارج از بازی و از Blum Memepad تهیه می‌شود؛ بازی فروشنده FUN نیست.", funNetwork: "شبکه", funContract: "آدرس Jetton", funBuy: "ورود به Blum Memepad", starsTitle: "⭐ قابلیت‌های ویژه", starsSoon: "قابلیت‌های ویژه به‌زودی", paid: "پرداخت دریافت شد! در حال بروزرسانی…",
    cancelled: "پرداخت لغو شد", blum: "باز کردن لانچ‌پد بلوم", fail: "مشکلی پیش آمد",
    ufo: { scout: "پیشاهنگ", comet: "دنباله‌دار", nova: "نوا", phantom: "شبح", vortex: "گردباد", eclipse: "کسوف", aurora: "شفق" },
  },
};
export const T = () => TXT[S.language];
export const fmt = (n) => Number(n || 0).toLocaleString(S.language === "fa" ? "fa-IR" : "en-US");
