export const $ = (id) => document.getElementById(id);
export function toast(msg) {
  const el = $("toast");
  el.textContent = msg; el.classList.remove("hidden");
  clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.add("hidden"), 2000);
}
