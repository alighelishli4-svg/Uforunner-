if (navigator.userAgent.includes("UFOAndroid")) document.documentElement.classList.add("android-app");
const box = document.getElementById("channelReminder");
const join = document.getElementById("channelJoin");
const later = document.getElementById("channelLater");
const isFa = () => (document.documentElement.lang || "").toLowerCase().startsWith("fa") || location.search.includes("lang=fa");
let channelUrl = "";
let shown = false;
function showReminder() {
  if (!channelUrl || document.hidden) return;
  const fa = isFa();
  document.getElementById("channelReminderTitle").textContent = fa ? "عضویت در کانال تلگرام بازی" : "Join our Telegram channel";
  document.getElementById("channelReminderText").textContent = fa ? "برای دریافت خبرها و اطلاعیه‌های بازی به کانال تلگرام ما بپیوندید." : "Join the channel for game news and announcements.";
  join.textContent = fa ? "عضویت در کانال" : "JOIN CHANNEL";
  later.textContent = fa ? "بعداً" : "LATER";
  box.classList.remove("hidden"); shown = true;
}
later?.addEventListener("click", () => box.classList.add("hidden"));
join?.addEventListener("click", () => {
  if (!channelUrl) return;
  if (window.Telegram?.WebApp?.openTelegramLink) window.Telegram.WebApp.openTelegramLink(channelUrl);
  else if (window.AndroidUFO?.isAndroidApp?.()) location.href = channelUrl;
  else window.open(channelUrl, "_blank", "noopener");
});
fetch("/api/public-config").then(r => r.json()).then(c => {
  channelUrl = typeof c.channel_url === "string" ? c.channel_url : "";
  if (!channelUrl) return;
  setTimeout(showReminder, 7000);
  setInterval(showReminder, 120000);
}).catch(() => {});
