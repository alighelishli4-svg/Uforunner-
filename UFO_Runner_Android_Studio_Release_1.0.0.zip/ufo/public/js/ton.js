import { $, toast } from "./ui.js";
import { S } from "./state.js";
import { T } from "./i18n.js";

let ui = null;
let initialized = false;
let currentWallet = null;

export async function initTonWallet() {
  const TonConnectUI = window.TON_CONNECT_UI?.TonConnectUI;
  if (!TonConnectUI) {
    toast(T().walletUnavailable);
    return;
  }
  if (!initialized) {
    initialized = true;
    ui = new TonConnectUI({
      manifestUrl: `${location.origin}/tonconnect-manifest.json`,
      buttonRootId: "tonWalletButton",
      language: S.language === "fa" ? "fa" : "en",
      actionsConfiguration: { twaReturnUrl: "https://t.me/" },
    });
    ui.onStatusChange(renderWallet);
  }
  renderWallet(ui.wallet);
}

export function openWallet() {
  $("home").classList.add("hidden");
  $("wallet").classList.remove("hidden");
  initTonWallet().catch(() => toast(T().fail));
  renderWallet(currentWallet || ui?.wallet);
}

export function closeWallet() {
  $("wallet").classList.add("hidden");
  $("home").classList.remove("hidden");
}

export async function disconnectWallet() {
  if (!ui || !currentWallet) return;
  try { await ui.disconnect(); }
  catch { toast(T().fail); }
}

function shortAddress(address) {
  return address ? `${address.slice(0, 7)}…${address.slice(-6)}` : "";
}

function renderWallet(wallet) {
  currentWallet = wallet || null;
  const address = wallet?.account?.address || "";
  const addressEl = $("walletAddress");
  addressEl.textContent = address ? `${T().walletConnected}: ${shortAddress(address)}` : T().walletDisconnected;
  addressEl.title = address;
  const info = $("walletInfo");
  info.replaceChildren();
  const rows = [
    [T().funNetwork, "TON"],
    [T().funContract, S.fun.tokenAddress || T().tokenNotConfigured],
    [T().funBalance, T().balanceAfterLaunch],
    [T().walletAccount, address ? shortAddress(address) : T().walletDisconnected],
  ];
  for (const [label, value] of rows) {
    const row = document.createElement("div");
    row.className = "wallet-row";
    const strong = document.createElement("b"); strong.textContent = `${label}: `;
    const span = document.createElement("span"); span.textContent = value;
    row.append(strong, span); info.appendChild(row);
  }
  const settlement = document.createElement("p"); settlement.className = "wallet-caption"; settlement.textContent = T().walletSettlement; info.appendChild(settlement);
  if (S.fun.note) {
    const note = document.createElement("p"); note.textContent = S.fun.note; info.appendChild(note);
  }
  const disconnect = $("walletDisconnect");
  disconnect.classList.toggle("hidden", !address);
  disconnect.textContent = T().disconnectWallet;
  disconnect.onclick = disconnectWallet;
  const buyLink = $("walletBuyFun");
  buyLink.classList.toggle("hidden", !S.fun.buyUrl);
  buyLink.textContent = T().funBuy;
  buyLink.onclick = () => {
    if (!S.fun.buyUrl) return;
    if (window.Telegram?.WebApp?.openLink) window.Telegram.WebApp.openLink(S.fun.buyUrl);
    else window.open(S.fun.buyUrl, "_blank", "noopener,noreferrer");
  };
}
