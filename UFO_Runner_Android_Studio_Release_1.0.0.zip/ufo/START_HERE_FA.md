# شروع نهایی ساخت نسخه اندروید UFO Runner

این بسته ادامه همان پروژه Android Studio است؛ پروژه جدید بازی از صفر ساخته نشده است.

## وضعیت این نسخه
- بازی وب، Worker و D1 مشترک با نسخه تلگرام حفظ شده‌اند.
- Referral و پاداش‌های Comet/Nova حفظ شده‌اند.
- FUN و اتصال TON حفظ شده‌اند؛ خرید UFO با FUN تا تکمیل و تأیید پرداخت واقعی TON همچنان طبق تصمیم مالک قفل است.
- F-35 و F-22 و نام سایر جنگنده‌ها حذف شده‌اند؛ فقط F-14 نام‌گذاری شده است. شناسه‌های داخلی هواپیماهای دیگر عمومی‌اند.
- ورود مستقل اندروید و اتصال اختیاری حساب تلگرام پیش‌بینی شده است.

## مرحله ۱ ـ استخراج
1. ZIP را Extract کن.
2. وارد پوشه `ufo` شو؛ این پوشه ریشه پروژه Cloudflare است.
3. پوشه `android-app` پروژه Android Studio است.

## مرحله ۲ ـ به‌روزرسانی سرور و دیتابیس
ابتدا از D1 فعلی در Cloudflare Dashboard نسخه پشتیبان بگیر. سپس وضعیت migrationها را بررسی کن. هر migration را فقط یک بار اجرا کن.

اگر دیتابیس فعلی تا migration شماره 003 به‌روز شده و 004 هنوز اجرا نشده، از ترمینال در ریشه پوشه `ufo` اجرا کن:

```bash
npx wrangler d1 execute ufo-runner-db --remote --file=migrations/004_fun_scarcity_nft.sql
```

سپس اگر migration شماره 006 قبلاً اجرا نشده:

```bash
npx wrangler d1 execute ufo-runner-db --remote --file=migrations/006_android_access.sql
```

و اگر migration شماره 007 قبلاً اجرا نشده:

```bash
npx wrangler d1 execute ufo-runner-db --remote --file=migrations/007_referrals.sql
```

اگر 004، 006 یا 007 قبلاً اجرا شده‌اند، همان فایل را دوباره اجرا نکن. بعد از تکمیل migrationها:

```bash
npx wrangler deploy
```

مقادیر `BOT_TOKEN`، `ADMIN_ID` و `WEBHOOK_SECRET` باید از قبل در Worker به‌عنوان Secret ثبت شده باشند؛ اگر ثبت نیستند، آن‌ها را از طریق `npx wrangler secret put ...` تنظیم کن. مقادیر محرمانه را داخل فایل‌ها یا چت قرار نده.

## مرحله ۳ ـ آدرس Worker
در Cloudflare به Worker با نام `ufo-runner` برو و آدرس HTTPS واقعی آن را کپی کن. سپس فایل زیر را باز کن:

`android-app/app/build.gradle.kts`

این خط را پیدا کن:

```kotlin
.orElse("https://YOUR-WORKER.workers.dev").get()
```

و فقط `https://YOUR-WORKER.workers.dev` را با آدرس واقعی Worker جایگزین کن؛ اسلش انتهایی نگذار. تا وقتی آدرس واقعی وارد نشده، APK قابل استفاده ساخته نمی‌شود.

## مرحله ۴ ـ بازکردن در Android Studio
1. Android Studio را باز کن.
2. از **Open** پوشه `android-app` را انتخاب کن، نه پوشه `ufo`.
3. SDK Platform 35 و JDK 17 را نصب/انتخاب کن.
4. Gradle Sync را اجرا کن.

### نکته درباره Gradle Wrapper
در این بسته فایل تنظیمات Wrapper وجود دارد، اما فایل اجرایی `gradlew` و `gradle-wrapper.jar` در محیط آماده‌سازی قابل تولید نبودند. اگر Android Studio خطای نبودن Wrapper داد:
1. از صفحه Welcome یک پروژه موقت **Empty Views Activity** بساز.
2. برای پروژه موقت، نام دلخواه و زبان Java انتخاب کن.
3. فایل‌های `gradlew`، `gradlew.bat` و پوشه `gradle/wrapper` (به‌خصوص `gradle-wrapper.jar`) را از پروژه موقت به ریشه `android-app` کپی کن.
4. فایل `gradle/wrapper/gradle-wrapper.properties` را با نسخه موجود در همین بسته نگه دار (Gradle 8.9).
5. دوباره پوشه `android-app` را باز و Gradle Sync را اجرا کن.

## مرحله ۵ ـ ساخت APK آزمایشی
در Android Studio:

**Build → Build Bundle(s) / APK(s) → Build APK(s)**

خروجی Debug در این مسیر خواهد بود:

`android-app/app/build/outputs/apk/debug/app-debug.apk`

آن را روی گوشی نصب و اتصال به Worker، ثبت کاربر، بازی، Referral، ذخیره امتیاز و همگام‌سازی را آزمایش کن.

## مرحله ۶ ـ ساخت APK انتشار
پس از موفقیت تست‌ها:

**Build → Generate Signed Bundle / APK → APK**

یک Keystore جدید بساز و رمزها را فقط نزد خودت نگه دار. همان Keystore باید برای تمام نسخه‌های بعدی استفاده شود. خروجی Release امضاشده را برای ارسال به بازار و مایکت استفاده کن. شناسه برنامه این نسخه `com.harifnews.uforunner` است؛ بعد از انتشار آن را تغییر نده.

## محدودیت‌های فعلی که باید بدانی
- این محیط نتوانست APK را کامپایل کند؛ Android SDK و Gradle Wrapper کامل در دسترس نبودند. بنابراین فایل APK امضاشده در ZIP وجود ندارد.
- پیام یادآوری عضویت کانال در نسخه اندروید دوره‌ای است؛ عضویت واقعی کاربر اندروید در این نسخه اثبات نمی‌شود.
- Telegram Stars در اپ مستقل اندروید خریدنی نیست و در Mini App تلگرام باقی می‌ماند.
- اتصال TON و داده‌های FUN حفظ شده‌اند؛ خرید واقعی UFO با FUN و مینت NFT تا تکمیل پرداخت و قرارداد واقعی فعال نیست.
- پذیرش نهایی قابلیت‌های FUN/TON در بازار یا مایکت را خود فروشگاه تعیین می‌کند. رایگان بودن دانلود به‌تنهایی تضمین تأیید همه قابلیت‌های توکنی نیست.
