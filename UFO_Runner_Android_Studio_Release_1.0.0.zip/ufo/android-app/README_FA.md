# راهنمای ساخت APK بازی UFO Runner با Android Studio

این پروژه یک اپ اندرویدی مستقل (WebView امن) برای بازی وب UFO Runner است. موتور بازی و API روی Cloudflare Worker می‌مانند؛ بنابراین هر دو نسخه از همان Worker و D1 استفاده می‌کنند.

## ۱) پیش‌نیازها
- Android Studio نسخه جدید (ترجیحاً Ladybug یا جدیدتر)
- Android SDK Platform 35 و Build Tools 35
- JDK 17 (Android Studio معمولاً خودش JBR دارد)
- اتصال اینترنت برای Gradle و Android SDK

## ۲) آدرس Worker را تنظیم کن
آدرس Worker را از Cloudflare بردار. هنگام ساخت، متغیر محیطی `GAME_URL` را با آدرس واقعی و بدون اسلش انتهایی تنظیم کن. اگر از Android Studio استفاده می‌کنی و متغیر محیط`ی را تنظیم نکرده‌ای، مقدار پیش‌فرض زیر را در app/build.gradle.kts` با آدرس واقعی جایگزین کن:

```kotlin
.orElse("https://YOUR-WORKER.workers.dev").get()
```

تا وقتی `YOUR-WORKER` در آدرس وجود دارد، APK را برای انتشار نساز؛ برنامه به Worker واقعی متصل نخواهد شد.

## ۳) ابتدا Worker و دیتابیس را به‌روزرسانی کن
این ZIP شامل اصلاحات سرور نیز هست. قبل از نصب APK، از D1 نسخه پشتیبان بگیر و migration جدید را فقط یک‌بار اجرا کن:

برای دیتابیس موجود که migration 003 را دارد و 004 هنوز اجرا نشده، ابتدا 004 و سپس 006 و 007 را اجرا کن. اگر 004 یا 006 قبلاً اجرا شده‌اند، آن‌ها را تکرار نکن:

```bash
npx wrangler d1 execute ufo-runner-db --remote --file=migrations/004_fun_scarcity_nft.sql
npx wrangler d1 execute ufo-runner-db --remote --file=migrations/006_android_access.sql
npx wrangler d1 execute ufo-runner-db --remote --file=migrations/007_referrals.sql
```

سپس Deploy:

```bash
npx wrangler deploy
```

این migration جدول نشست‌های اندروید و کدهای اتصال را می‌سازد؛ migration شماره 007 نیز سیستم Referral و پاداش‌های Comet/Nova را فعال می‌کند. اگر migration 006 قبلاً اجرا شده، فقط 007 را اجرا کن. آدرس کانال را ادمین از داخل تلگرام تنظیم می‌کند:

```text
/channel https://t.me/YourChannel
```

خاموش‌کردن پیام کانال:

```text
/channel off
```

ربات باید در کانال عضو و ترجیحاً ادمین باشد تا در آینده امکان بررسی عضویت واقعی هم اضافه شود. در این نسخه پیام عضویت به‌صورت دوره‌ای نمایش داده می‌شود؛ صرف نمایش پیام، اثبات عضویت نیست.

## ۴) بازکردن پروژه در Android Studio
1. پوشه `android-app` را از Android Studio با گزینه **Open** باز کن.
2. صبر کن Gradle Sync تمام شود و SDKهای درخواستی نصب شوند.
3. از منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)** خروجی بگیر.
4. APK در مسیر زیر ساخته می‌شود:

`app/build/outputs/apk/debug/app-debug.apk`

برای نسخه انتشار، از **Build > Generate Signed Bundle / APK** استفاده کن و کلید امضای خودت را بساز و امن نگه دار.

## ۵) ورود مستقل و همگام‌سازی
- اولین اجرای اپ، از Worker یک نشست اندرویدی می‌گیرد؛ توکن در SharedPreferences خصوصی اپ ذخیره می‌شود و در درخواست‌های بازی به‌صورت Bearer Token ارسال می‌شود.
- بازیکن می‌تواند بدون ورود تلگرام بازی کند.
- برای اینکه همان حساب و موجودی تلگرام و اندروید یکی شود، داخل بازی دکمه **LINK TELEGRAM ACCOUNT** را بزن؛ کد نمایش‌داده‌شده را در ربات `@Ufo2026_game_bot` با دستور `/link CODE` ارسال کن. پس از تأیید ربات، پیشرفت حساب مهمان به حساب تلگرام منتقل و نشست اندروید به همان شناسه وصل می‌شود.
- پس از اتصال، تغییرات هر دو نسخه در همان ردیف کاربر D1 ثبت می‌شود.
- خریدهای Telegram Stars فقط در نسخه تلگرام فعال‌اند؛ در اپ مستقل، بخش Stars مخفی است. سایر اطلاعات و پیشرفت بازی، از جمله Referral و وضعیت FUN، از سرور مشترک خوانده می‌شود.

## ۶) نکات مهم
- آدرس Worker باید HTTPS باشد؛ HTTP ناامن در اپ مسدود است.
- این APK پوسته آفلاین نیست؛ برای بازی و همگام‌سازی اینترنت لازم است.
- قبل از اجرای migration روی دیتابیس اصلی، حتماً backup بگیر.
- توکن نشست فقط روی دستگاه ذخیره می‌شود. پاک‌کردن داده‌های اپ یا نصب مجدد، نشست محلی را از بین می‌برد؛ در آن حالت یک حساب مهمان تازه ساخته می‌شود و برای اتصال مجدد باید کد جدید تولید شود.
- نسخه Debug برای آزمایش است؛ برای انتشار عمومی APK امضاشده بساز.

### اگر Gradle Sync به‌دلیل Wrapper ناقص متوقف شد
در بعضی نصب‌ها Android Studio به فایل Wrapper نیاز دارد. در این حالت از صفحه Welcome گزینه **New Project > Empty Views Activity** را انتخاب کن، نام پروژه را `UFO Runner` و package را `com.harifnews.uforunner` بگذار، سپس پروژه ساخته‌شده را ببند و پوشه `app` و فایل‌های `settings.gradle.kts`، `build.gradle.kts` و `gradle.properties` این بسته را جایگزین کن؛ پوشه `gradle/wrapper` و فایل‌های `gradlew` پروژه‌ای که Android Studio ساخته را نگه دار. بعد دوباره Sync کن.


## ساخت APK با GitHub Actions (اختیاری)
در صورت آپلود پروژه به GitHub، Workflow موجود در `.github/workflows/android-build.yml` می‌تواند APK آزمایشی را بسازد. در بخش Repository Variables مقدار `GAME_URL` را برابر آدرس واقعی Worker قرار بده. برای خروجی Release امضاشده، Keystore خودت را به Base64 تبدیل و این Secrets را تنظیم کن: `ANDROID_KEYSTORE_BASE64`، `KEYSTORE_PASSWORD`، `KEY_ALIAS` و `KEY_PASSWORD`. بدون کلید امضا فقط APK آزمایشی Debug ساخته می‌شود.
