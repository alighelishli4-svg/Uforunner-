package com.harifnews.uforunner;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private ProgressBar progress;
    private SharedPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private static final String PREFS = "ufo_secure_session";
    private static final String TOKEN_KEY = "session_token";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7, 13, 36));
        getWindow().setNavigationBarColor(Color.rgb(7, 13, 36));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, 6);
        root.addView(progress, pp);
        setContentView(root);

        configureWebView();
        String token = prefs.getString(TOKEN_KEY, "");
        if (token.isEmpty()) registerAndOpen(); else openGame();
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        webView.setBackgroundColor(Color.rgb(7, 13, 36));
        webView.getSettings().setUserAgentString(s.getUserAgentString() + " UFOAndroid/1.0");
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidUFO");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int p) {
                progress.setProgress(p); progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(Uri.parse(url));
            }
        });
    }

    private boolean routeUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
        Uri base = Uri.parse(BuildConfig.GAME_URL);
        if (scheme.equals("https") && host.equalsIgnoreCase(base.getHost())) return false;
        if (scheme.equals("https") || scheme.equals("http") || scheme.equals("tg") || scheme.equals("ton")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (Exception e) { Toast.makeText(this, "لینک قابل بازشدن نیست", Toast.LENGTH_SHORT).show(); }
            return true;
        }
        return true;
    }

    private void registerAndOpen() {
        io.execute(() -> {
            try {
                URL url = new URL(BuildConfig.GAME_URL + "/api/android/register");
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(15000);
                c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
                try (OutputStream os = c.getOutputStream()) { os.write("{}".getBytes(StandardCharsets.UTF_8)); }
                int code = c.getResponseCode();
                InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                StringBuilder b = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                    String line; while ((line = r.readLine()) != null) b.append(line);
                }
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + b);
                String token = new JSONObject(b.toString()).optString("token", "");
                if (token.length() != 64) throw new Exception("Invalid session response");
                prefs.edit().putString(TOKEN_KEY, token).apply();
                runOnUiThread(this::openGame);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "اتصال اولیه به سرور ناموفق بود. اینترنت و آدرس Worker را بررسی کن.", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void openGame() {
        webView.loadUrl(BuildConfig.GAME_URL + "/");
    }

    public class AndroidBridge {
        @JavascriptInterface public String getToken() { return prefs.getString(TOKEN_KEY, ""); }
        @JavascriptInterface public boolean isAndroidApp() { return true; }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("AndroidUFO"); webView.destroy(); }
        io.shutdownNow(); super.onDestroy();
    }
}
