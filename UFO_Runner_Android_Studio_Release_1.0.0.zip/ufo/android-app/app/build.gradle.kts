plugins { id("com.android.application") }

val configuredGameUrl = providers.environmentVariable("GAME_URL")
    .orElse( "https://ufo-runner.ufosubdomain.workers.dev").get()
val releaseKeyPath = System.getenv("ANDROID_KEYSTORE_PATH")
val hasReleaseKey = !releaseKeyPath.isNullOrBlank()

android {
    namespace = "com.harifnews.uforunner"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.harifnews.uforunner"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        // Supply GAME_URL as an environment variable when building; do not include a trailing slash.
        buildConfigField("String", "GAME_URL", "\"${configuredGameUrl.replace("\\", "\\\\").replace("\"", "\\\"")}\"")
    }

    signingConfigs {
        if (hasReleaseKey) {
            create("release") {
                storeFile = file(releaseKeyPath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (hasReleaseKey) signingConfig = signingConfigs.getByName("release")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
