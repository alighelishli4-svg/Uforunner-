# UFO Runner APK builder - robust download validation, ASCII-only.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Step([int]$N,[string]$Text) {
  Write-Host "`n========== [$N/6] $Text ==========" -ForegroundColor Cyan
}
function Download-VerifiedZip([string]$Url,[string]$Path,[string]$Name) {
  $valid = $false
  if (Test-Path $Path) {
    try {
      $z = [System.IO.Compression.ZipFile]::OpenRead($Path)
      $z.Dispose(); $valid = $true
      Write-Host "$Name archive already valid; reusing it." -ForegroundColor Green
    } catch {
      Write-Host "Removing damaged cached $Name archive..." -ForegroundColor Yellow
      Remove-Item $Path -Force -ErrorAction SilentlyContinue
    }
  }
  if (!$valid) {
    Write-Host "Downloading $Name. Please wait..." -ForegroundColor Yellow
    $ok = $false
    for ($attempt=1; $attempt -le 3; $attempt++) {
      try {
        Remove-Item $Path -Force -ErrorAction SilentlyContinue
        Invoke-WebRequest -Uri $Url -OutFile $Path -UseBasicParsing -MaximumRedirection 10
        $z = [System.IO.Compression.ZipFile]::OpenRead($Path)
        $entries = $z.Entries.Count
        $z.Dispose()
        if ($entries -lt 1) { throw 'Archive has no entries.' }
        $ok = $true
        break
      } catch {
        Write-Host "Download/ZIP validation attempt $attempt failed: $($_.Exception.Message)" -ForegroundColor Red
        Remove-Item $Path -Force -ErrorAction SilentlyContinue
        if ($attempt -lt 3) { Start-Sleep -Seconds 3 }
      }
    }
    if (!$ok) { throw "$Name download is not a valid ZIP. Check internet/VPN/proxy, then rerun this script." }
  }
}
function Expand-VerifiedZip([string]$Zip,[string]$Dest) {
  if (Test-Path $Dest) { Remove-Item $Dest -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $Dest | Out-Null
  Expand-Archive -LiteralPath $Zip -DestinationPath $Dest -Force
}

Write-Host 'UFO RUNNER - AUTOMATIC ANDROID APK BUILDER' -ForegroundColor Magenta
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Candidates = @($ScriptDir,(Join-Path $ScriptDir '..'),(Join-Path (Get-Location).Path 'android-app'),(Get-Location).Path)
$Project = $null
foreach ($p in $Candidates) {
  $p = [IO.Path]::GetFullPath($p)
  if ((Test-Path (Join-Path $p 'settings.gradle.kts')) -and (Test-Path (Join-Path $p 'app\build.gradle.kts'))) { $Project=$p; break }
}
if (!$Project) { throw 'Cannot locate android-app. Put this script inside the android-app folder.' }
Set-Location $Project
Write-Host "Project folder: $Project" -ForegroundColor Green
$Worker = (Read-Host 'Enter your REAL Cloudflare Worker HTTPS URL').Trim().TrimEnd('/')
if ($Worker -notmatch '^https://[^/]+') { throw 'Worker URL must start with https:// and be the real workers.dev address.' }

$Tools = Join-Path $HOME 'UFO-Android-Tools'
New-Item -ItemType Directory -Force -Path $Tools | Out-Null

Step 1 'Prepare Java 17'
$JdkRoot = Join-Path $Tools 'jdk17'
$Jdk = Get-ChildItem $JdkRoot -Directory -ErrorAction SilentlyContinue | Select-Object -First 1
if (!$Jdk -or !(Test-Path (Join-Path $Jdk.FullName 'bin\java.exe'))) {
  $zip = Join-Path $Tools 'jdk17.zip'
  Download-VerifiedZip 'https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse' $zip 'JDK 17'
  Expand-VerifiedZip $zip $JdkRoot
  Remove-Item $zip -Force
  $Jdk = Get-ChildItem $JdkRoot -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'bin\java.exe') } | Select-Object -First 1
}
if (!$Jdk) { throw 'JDK 17 extraction failed: java.exe not found.' }
$env:JAVA_HOME=$Jdk.FullName; $env:Path="$($Jdk.FullName)\bin;$env:Path"
& "$env:JAVA_HOME\bin\java.exe" -version
if ($LASTEXITCODE -ne 0) { throw 'Java validation failed.' }

Step 2 'Download Android SDK command-line tools'
$Sdk = Join-Path $Tools 'Sdk'
$Manager = Join-Path $Sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
if (!(Test-Path $Manager)) {
  $zip = Join-Path $Tools 'android-cmdline.zip'
  Download-VerifiedZip 'https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip' $zip 'Android command-line tools'
  $tmp = Join-Path $Tools 'cmdline-extract'
  Expand-VerifiedZip $zip $tmp
  New-Item -ItemType Directory -Force -Path (Join-Path $Sdk 'cmdline-tools') | Out-Null
  if (Test-Path (Join-Path $Sdk 'cmdline-tools\latest')) { Remove-Item (Join-Path $Sdk 'cmdline-tools\latest') -Recurse -Force }
  Move-Item (Join-Path $tmp 'cmdline-tools') (Join-Path $Sdk 'cmdline-tools\latest')
  Remove-Item $tmp -Recurse -Force; Remove-Item $zip -Force
}
if (!(Test-Path $Manager)) { throw 'sdkmanager.bat not found after extraction.' }
$env:ANDROID_HOME=$Sdk; $env:ANDROID_SDK_ROOT=$Sdk

Step 3 'Accept licenses and install Android SDK 35'
Write-Host 'Accept licenses by typing y when prompted.' -ForegroundColor Yellow
& $Manager "--sdk_root=$Sdk" --licenses
if ($LASTEXITCODE -ne 0) { throw 'SDK license step failed.' }
& $Manager "--sdk_root=$Sdk" 'platform-tools' 'platforms;android-35' 'build-tools;35.0.0'
if ($LASTEXITCODE -ne 0) { throw 'Android SDK installation failed.' }

Step 4 'Prepare Gradle 8.9'
$GradleDir = Join-Path $Tools 'gradle-8.9'
$Gradle = Join-Path $GradleDir 'bin\gradle.bat'
if (!(Test-Path $Gradle)) {
  $zip = Join-Path $Tools 'gradle-8.9-bin.zip'
  Download-VerifiedZip 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' $zip 'Gradle 8.9'
  Expand-Archive -LiteralPath $zip -DestinationPath $Tools -Force
  Remove-Item $zip -Force
}
if (!(Test-Path $Gradle)) { throw 'Gradle 8.9 installation failed.' }

Step 5 'Build debug APK'
Write-Host "Worker URL entered: $Worker" -ForegroundColor DarkGray
Write-Host 'Gradle build can take several minutes...' -ForegroundColor Yellow
& $Gradle --no-daemon --console=plain assembleDebug
if ($LASTEXITCODE -ne 0) { throw 'Gradle build failed. Send the LAST 30 lines of output.' }

Step 6 'Copy APK to Desktop'
$Apk = Join-Path $Project 'app\build\outputs\apk\debug\app-debug.apk'
if (!(Test-Path $Apk)) { throw "APK not found at $Apk" }
$Desktop = [Environment]::GetFolderPath('Desktop')
$Out = Join-Path $Desktop 'UFO-Runner-debug.apk'
Copy-Item $Apk $Out -Force
Write-Host "`nSUCCESS: $Out" -ForegroundColor Green
Write-Host "APK size: $([math]::Round((Get-Item $Out).Length/1MB,2)) MB" -ForegroundColor Green
Start-Process explorer.exe -ArgumentList "/select,`"$Out`""
